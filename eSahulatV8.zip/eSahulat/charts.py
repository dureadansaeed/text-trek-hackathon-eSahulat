"""
charts.py - small chart helpers that return plain svg / html strings.

We draw the charts by hand (no plotting library) so the demo has no extra dependency and every colour
comes from the page theme in app.py. Every function returns ONE line of html with no blank lines,
because Streamlit's markdown breaks on blank lines inside html.
"""
import html
import math


def esc(text):
    return html.escape(str(text))


def wrapLabel(text, width=14):
    # split a long label into short lines so it fits under a bar
    lines, current = [], ""
    for word in str(text).split():
        if current and len(current) + 1 + len(word) > width:
            lines.append(current)
            current = word
        else:
            current = (current + " " + word).strip()
    lines.append(current)
    return lines


def svgStart(width, height, description):
    return "<svg viewBox='0 0 %d %d' class='chartSvg' role='img' aria-label='%s'>" % (width, height, esc(description))


# ------------------------------------------------------------------ grouped bar chart
def groupedBarSvg(categories, seriesNames, values, formatters, description):
    """values[seriesIndex][categoryIndex] is a number between 0 and 1"""
    width, height = 720, 330
    left, right, top, bottom = 46, 12, 40, 70
    plotWidth, plotHeight = width - left - right, height - top - bottom
    parts = [svgStart(width, height, description)]

    for tick in (0, 0.25, 0.5, 0.75, 1.0):
        y = top + plotHeight * (1 - tick)
        parts.append("<line x1='%d' y1='%.1f' x2='%d' y2='%.1f' class='svgGrid'/>" % (left, y, width - right, y))
        parts.append("<text x='%d' y='%.1f' class='svgText small' text-anchor='end'>%d%%</text>" % (left - 6, y + 4, tick * 100))

    groupWidth = plotWidth / len(categories)
    barWidth = groupWidth * 0.76 / len(seriesNames)
    for categoryIndex, category in enumerate(categories):
        groupStart = left + categoryIndex * groupWidth + groupWidth * 0.12
        for seriesIndex in range(len(seriesNames)):
            value = values[seriesIndex][categoryIndex]
            barHeight = plotHeight * value
            x = groupStart + seriesIndex * barWidth
            y = top + plotHeight - barHeight
            parts.append("<rect x='%.1f' y='%.1f' width='%.1f' height='%.1f' class='bar%s'/>" % (
                x, y, barWidth - 3, barHeight, "AB"[seriesIndex % 2]))
            parts.append("<text x='%.1f' y='%.1f' class='svgText small' text-anchor='middle'>%s</text>" % (
                x + (barWidth - 3) / 2, y - 5, esc(formatters[seriesIndex](value))))
        centre = left + categoryIndex * groupWidth + groupWidth / 2
        for lineNumber, line in enumerate(wrapLabel(category)):
            parts.append("<text x='%.1f' y='%.1f' class='svgText' text-anchor='middle'>%s</text>" % (
                centre, top + plotHeight + 18 + lineNumber * 14, esc(line)))

    legendX = left
    for seriesIndex, name in enumerate(seriesNames):
        parts.append("<rect x='%d' y='10' width='12' height='12' class='bar%s'/>" % (legendX, "AB"[seriesIndex % 2]))
        parts.append("<text x='%d' y='20' class='svgText'>%s</text>" % (legendX + 18, esc(name)))
        legendX += 30 + 8 * len(name)
    parts.append("</svg>")
    return "".join(parts)


# ------------------------------------------------------------------ line chart
def lineChartSvg(seriesList, yMin, yMax, yStep, yAsPercent, yTitle, xTitle, markerX=None, markerText="", description=""):
    """seriesList = [(name, [(x, y), ...])] with x between 0 and 1"""
    width, height = 720, 320
    left, right, top, bottom = 56, 16, 40, 52
    plotWidth, plotHeight = width - left - right, height - top - bottom

    def px(xValue):
        return left + plotWidth * xValue

    def py(yValue):
        return top + plotHeight * (1 - (yValue - yMin) / (yMax - yMin))

    parts = [svgStart(width, height, description or yTitle)]
    tickCount = int(round((yMax - yMin) / yStep))
    for step in range(tickCount + 1):
        yValue = yMin + yStep * step
        tickText = "%.0f%%" % (yValue * 100) if yAsPercent else "%.2f" % yValue
        parts.append("<line x1='%d' y1='%.1f' x2='%d' y2='%.1f' class='svgGrid'/>" % (left, py(yValue), width - right, py(yValue)))
        parts.append("<text x='%d' y='%.1f' class='svgText small' text-anchor='end'>%s</text>" % (left - 6, py(yValue) + 4, tickText))
    for step in range(11):
        xValue = step / 10
        parts.append("<text x='%.1f' y='%d' class='svgText small' text-anchor='middle'>%.1f</text>" % (px(xValue), top + plotHeight + 16, xValue))
    parts.append("<text x='%.1f' y='%d' class='svgText' text-anchor='middle'>%s</text>" % (left + plotWidth / 2, height - 8, esc(xTitle)))
    parts.append("<text transform='translate(14 %.1f) rotate(-90)' class='svgText' text-anchor='middle'>%s</text>" % (top + plotHeight / 2, esc(yTitle)))

    if markerX is not None:
        parts.append("<line x1='%.1f' y1='%d' x2='%.1f' y2='%d' class='markerLine'/>" % (px(markerX), top, px(markerX), top + plotHeight))
        parts.append("<text x='%.1f' y='%d' class='svgText small' text-anchor='middle'>%s</text>" % (px(markerX), top - 6, esc(markerText)))

    legendX = left
    for seriesIndex, (name, points) in enumerate(seriesList):
        cssLetter = "AB"[seriesIndex % 2]
        pointText = " ".join("%.1f,%.1f" % (px(x), py(y)) for x, y in points)
        parts.append("<polyline points='%s' class='line%s'/>" % (pointText, cssLetter))
        for x, y in points:
            parts.append("<circle cx='%.1f' cy='%.1f' r='3.5' class='dot%s'/>" % (px(x), py(y), cssLetter))
        parts.append("<rect x='%d' y='6' width='12' height='12' class='bar%s'/>" % (legendX, cssLetter))
        parts.append("<text x='%d' y='16' class='svgText'>%s</text>" % (legendX + 18, esc(name)))
        legendX += 30 + 7 * len(name)
    parts.append("</svg>")
    return "".join(parts)


# ------------------------------------------------------------------ scatter plot with a star for the question
def starPoints(centreX, centreY, outer=14, inner=6):
    points = []
    for corner in range(10):
        radius = outer if corner % 2 == 0 else inner
        angle = -math.pi / 2 + corner * math.pi / 5
        points.append("%.1f,%.1f" % (centreX + radius * math.cos(angle), centreY + radius * math.sin(angle)))
    return " ".join(points)


def scatterSvg(points, queryPoint, description):
    """points = [{x, y, label, role}] with role first / top / other; queryPoint = (x, y) or None"""
    width, height = 720, 440
    pad = 36
    allX = [p["x"] for p in points] + ([queryPoint[0]] if queryPoint else [])
    allY = [p["y"] for p in points] + ([queryPoint[1]] if queryPoint else [])
    xLow, xHigh, yLow, yHigh = min(allX), max(allX), min(allY), max(allY)
    xSpan, ySpan = max(xHigh - xLow, 1e-9), max(yHigh - yLow, 1e-9)

    def px(value):
        return pad + (width - 2 * pad) * (value - xLow) / xSpan

    def py(value):
        return height - pad - (height - 2 * pad - 10) * (value - yLow) / ySpan

    parts = [svgStart(width, height, description)]
    parts.append("<rect x='1' y='1' width='%d' height='%d' class='svgFrame'/>" % (width - 2, height - 2))
    parts.append("<text x='%d' y='%d' class='svgText small' text-anchor='middle'>PCA axis 1</text>" % (width / 2, height - 10))
    parts.append("<text transform='translate(14 %d) rotate(-90)' class='svgText small' text-anchor='middle'>PCA axis 2</text>" % (height / 2))

    topOne = next((p for p in points if p["role"] == "first"), None)
    if queryPoint and topOne:
        parts.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' class='markerLine'/>" % (
            px(queryPoint[0]), py(queryPoint[1]), px(topOne["x"]), py(topOne["y"])))
    for point in sorted(points, key=lambda p: {"other": 0, "top": 1, "first": 2}[p["role"]]):
        radius = {"other": 5, "top": 7, "first": 9}[point["role"]]
        parts.append("<circle cx='%.1f' cy='%.1f' r='%d' class='scatter%s'><title>%s</title></circle>" % (
            px(point["x"]), py(point["y"]), radius, point["role"].capitalize(), esc(point["title"])))
        parts.append("<text x='%.1f' y='%.1f' class='svgText tiny'>%s</text>" % (px(point["x"]) + radius + 3, py(point["y"]) - 4, esc(point["label"])))
    if queryPoint:
        parts.append("<polygon points='%s' class='starQuery'><title>Your question</title></polygon>" % starPoints(px(queryPoint[0]), py(queryPoint[1])))
    parts.append("</svg>")
    return "".join(parts)


# ------------------------------------------------------------------ html grids and bars
def heatmapHtml(rows, languageOrder, languageNames):
    """rows = [{passageId, topic, cells: {language: {status, query}}}]"""
    words = {"top1": "Top 1", "top5": "In top 5", "miss": "Missed", "none": "no question"}
    cells = ["<div class='hmHead'>Question topic</div>"] + ["<div class='hmHead'>%s</div>" % esc(languageNames[l]) for l in languageOrder]
    for row in rows:
        cells.append("<div class='hmLabel' title='%s'><b>%s</b> %s</div>" % (esc(row["topic"]), esc(row["passageId"]), esc(row["topic"].replace("_", " "))))
        for language in languageOrder:
            cell = row["cells"][language]
            cells.append("<div class='hmCell hm%s' title='%s'>%s</div>" % (cell["status"].capitalize(), esc(cell.get("query", "")), words[cell["status"]]))
    return "<div class='hmGrid' role='table'>%s</div>" % "".join(cells)


def confusionHtml(answeredRight, abstainedWrong, answeredWrong, abstainedRight):
    """2x2 grid: rows = what the question really was, columns = what the system did"""
    answerableTotal = answeredRight + abstainedWrong
    negativeTotal = answeredWrong + abstainedRight
    return (
        "<div class='cmGrid' role='table'>"
        "<div class='cmCorner'></div><div class='cmHead'>System answered</div><div class='cmHead'>System abstained or asked for detail</div>"
        "<div class='cmSide'>Answerable question<span>%d questions</span></div>"
        "<div class='cmCell cmGood'><b>%d</b><span>answered correctly</span></div>"
        "<div class='cmCell %s'><b>%d</b><span>false abstentions</span></div>"
        "<div class='cmSide'>Unanswerable question<span>%d questions</span></div>"
        "<div class='cmCell %s'><b>%d</b><span>false answers</span></div>"
        "<div class='cmCell cmGood'><b>%d</b><span>correctly held back</span></div>"
        "</div>" % (answerableTotal, answeredRight, "cmBad" if abstainedWrong else "cmZero", abstainedWrong,
                    negativeTotal, "cmBad" if answeredWrong else "cmZero", answeredWrong, abstainedRight))


def barRowsHtml(rows):
    """rows = [(label, fraction 0..1, shownText)] - a plain horizontal bar list"""
    parts = []
    for label, fraction, shownText in rows:
        parts.append("<div class='meterRow'><span>%s</span><div class='meterTrack'><div class='meterFill' style='width:%.0f%%'></div></div>"
                     "<span class='meterNum'>%s</span></div>" % (esc(label), 100 * max(0.0, min(1.0, fraction)), esc(shownText)))
    return "".join(parts)


def scoreBarsHtml(rows, barNames):
    """rows = [{label, isTop, values: [(fraction, text), ...]}] one thin bar per name (keyword, meaning, mix)"""
    legend = "".join("<span class='sbLegend'><i class='sbSwatch sb%d'></i>%s</span>" % (number, esc(name)) for number, name in enumerate(barNames))
    parts = ["<div class='sbLegendRow'>%s</div>" % legend]
    for row in rows:
        bars = "".join(
            "<div class='sbLine'><div class='sbTrack'><div class='sbFill sb%d' style='width:%.0f%%'></div></div><span class='sbText'>%s</span></div>"
            % (number, 100 * max(0.0, min(1.0, fraction)), esc(text)) for number, (fraction, text) in enumerate(row["values"]))
        parts.append("<div class='sbRow%s'><div class='sbLabel'><b>%s</b> %s</div><div class='sbBars'>%s</div></div>" % (
            " sbTop" if row["isTop"] else "", esc(row["passageId"]), esc(row["topic"].replace("_", " ")), bars))
    return "".join(parts)


def gaugeHtml(ratio, headline, note, neutral=False):
    """strength of the evidence as a share of the answer line (100% = exactly on the line)"""
    fill = max(0.0, min(2.0, ratio)) / 2 * 100
    stateClass = "gaugeIdle" if neutral else ("gaugeOk" if ratio >= 1 else "gaugeLow")
    return ("<div class='gauge'><div class='gaugeTop'><span class='gaugeHead'>%s</span><span class='gaugeNote'>%s</span></div>"
            "<div class='gaugeTrack'><div class='gaugeFill %s' style='width:%.0f%%'></div><div class='gaugeTick'></div></div>"
            "<div class='gaugeScale'><span>0%%</span><span>answer line (100%%)</span><span>200%%</span></div></div>"
            % (esc(headline), esc(note), stateClass, fill))
