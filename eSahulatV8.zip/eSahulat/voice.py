"""
voice.py - speech to text for the microphone button, fully local.

We use faster-whisper, an open-source re-implementation of OpenAI's Whisper that runs on this machine.
No audio leaves the computer and no hosted API is called. The model is downloaded once from Hugging Face,
the same way the e5 embedding model is.

Whisper writes Urdu speech in Urdu script and English speech in English. It does not write Roman Urdu,
which is fine: the search pipeline already understands Urdu script.
"""
import io
import time
import wave

import numpy as np

# what the person can pick in the app -> the language code Whisper wants (None = let Whisper decide)
speechLanguages = {"Auto": None, "Urdu": "ur", "English": "en"}


def loadModel(sizeName="small"):
    """returns (model, errorText); exactly one of them is None"""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None, "The speech package is missing. Run:  pip install faster-whisper"
    try:
        # int8 keeps memory low on the free Colab CPU and also works on a GPU
        return WhisperModel(sizeName, device="auto", compute_type="int8"), None
    except Exception as problem:                      # download or device problems
        return None, "Could not load the speech model (%s): %s" % (sizeName, problem)


def wavToSamples(audioBytes):
    """reads the browser's wav recording ourselves, so we do not depend on the av/ffmpeg decoder.
    Returns mono float32 samples at 16000 Hz, which is what Whisper expects."""
    with wave.open(io.BytesIO(audioBytes), "rb") as wavFile:
        channels, sampleWidth, rate = wavFile.getnchannels(), wavFile.getsampwidth(), wavFile.getframerate()
        rawBytes = wavFile.readframes(wavFile.getnframes())
    if sampleWidth == 2:
        samples = np.frombuffer(rawBytes, dtype=np.int16).astype(np.float32) / 32768.0
    elif sampleWidth == 4:
        samples = np.frombuffer(rawBytes, dtype=np.int32).astype(np.float32) / 2147483648.0
    elif sampleWidth == 1:
        samples = (np.frombuffer(rawBytes, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
    else:
        raise ValueError("unsupported wav sample width: %d bytes" % sampleWidth)
    if channels > 1:
        samples = samples.reshape(-1, channels).mean(axis=1)           # mix stereo down to mono
    if rate != 16000 and len(samples) > 1:
        newLength = int(len(samples) * 16000 / rate)
        samples = np.interp(np.linspace(0, len(samples) - 1, newLength), np.arange(len(samples)), samples).astype(np.float32)
    return samples


def transcribe(model, audioBytes, languageCode=None):
    """turns recorded audio (wav bytes) into text; returns a small dict the app can show"""
    start = time.perf_counter()
    try:
        try:
            audioInput = wavToSamples(audioBytes)
        except Exception:
            audioInput = io.BytesIO(audioBytes)             # not a plain wav: let faster-whisper try its own decoder
        segments, info = model.transcribe(audioInput, language=languageCode, beam_size=5, vad_filter=True)
        text = " ".join(segment.text.strip() for segment in segments).strip()
    except Exception as problem:
        return {"text": "", "language": None, "seconds": 0.0, "error": "Could not read the recording: %s" % problem}
    return {"text": text, "language": info.language, "seconds": round(time.perf_counter() - start, 1), "error": None}
