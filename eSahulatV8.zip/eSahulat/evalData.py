"""
evalData.py - collects every number the Evaluation tab of the app needs and saves it to one json file.

evaluate.py calls buildAndSave() at the end of its run, and the app can also call it from a button,
so the numbers on screen always come from the same functions that wrote evaluationReport.md.
Nothing here is typed in by hand.
"""
import json
import os
import statistics
import time

import numpy as np

import eSahulatCore as core
import evaluate as ev

resultsFolder = "results"
methods = core.EsahulatEngine.retrievalMethods
languageOrder = ["ur", "roman_ur", "en"]
weightGrid = [round(step / 10, 1) for step in range(11)]       # 0.0, 0.1 ... 1.0
latencyQueryCount = 40                                         # latency is measured on an even sample of the queries


def cachePath(embedderName):
    return os.path.join(resultsFolder, "evalTab_%s.json" % embedderName.replace("/", "_"))


def loadSaved(embedderName):
    try:
        return core.loadJson(cachePath(embedderName))
    except (OSError, ValueError):
        return None


# ------------------------------------------------------------------ one split (dev or test)
def statusOfRank(rank):
    if rank == 1:
        return "top1"
    return "top5" if rank else "miss"


def heatmapRows(engine, answerable, hybridRanks):
    """one row per passage (intent), one cell per language style: did hybrid retrieval find it?"""
    severity = {"top1": 0, "top5": 1, "miss": 2}
    rows = []
    for passage in engine.passages:
        cells = {}
        for language in languageOrder:
            matching = [q for q in answerable if q["relevantPassageId"] == passage["passageId"] and q["language"] == language]
            if not matching:
                cells[language] = {"status": "none", "query": ""}
                continue
            # if one language has several questions for the same passage, show the worst one
            worst = max(matching, key=lambda q: severity[statusOfRank(hybridRanks[q["queryId"]])])
            cells[language] = {"status": statusOfRank(hybridRanks[worst["queryId"]]), "query": worst["text"]}
        if any(cell["status"] != "none" for cell in cells.values()):
            rows.append({"passageId": passage["passageId"], "topic": passage["topic"], "cells": cells})
    return rows


def failureRows(stats, splitName):
    rows = []
    for outcome in stats["outcomes"]:
        query, result = outcome["query"], outcome["result"]
        if query["answerable"] and not outcome["answered"]:
            kind = "False abstention"
        elif query["answerable"] and outcome["citedId"] != query["relevantPassageId"]:
            kind = "Wrong passage cited"
        elif not query["answerable"] and outcome["answered"]:
            kind = "False answer"
        else:
            continue
        rows.append({
            "split": splitName, "queryId": query["queryId"], "language": query["language"], "question": query["text"],
            "expected": query["relevantPassageId"] or "nothing (should not answer)",
            "systemDid": "answered with " + str(outcome["citedId"]) if outcome["answered"] else "did not answer",
            "reasonCode": result["reasonCode"], "keywordMatch": result["coverage"], "meaningMatch": result["semanticScore"],
            "top5": ", ".join(result["retrievedPassageIds"]),
            "type": kind,
        })
    return rows


def evaluateSplit(engine, queries, splitName):
    summary, perMethod, answerable = ev.evaluateRetrieval(engine, queries, methods)
    stats = ev.evaluateSystem(engine, queries)
    return {
        "name": splitName,
        "questionCount": len(queries), "answerableCount": len(answerable),
        "retrieval": {method: summary[method]["overall"] for method in methods},
        "heatmap": heatmapRows(engine, answerable, perMethod["hybrid"]["ranks"]),
        "confusion": {"answeredRight": stats["answeredAnswerable"], "abstainedWrong": stats["falseAbstentions"],
                      "answeredWrong": stats["falseAnswers"], "abstainedRight": stats["correctAbstentions"]},
        "failures": failureRows(stats, splitName),
    }


# ------------------------------------------------------------------ weight sweep (dev only, same grid idea as tuneFusion)
def weightSweep(engine, devQueries):
    answerable = [q for q in devQueries if q["answerable"]]
    scoreCache = [engine.scoreAll(q["text"]) for q in answerable]
    oldMode, oldWeight = engine.params["fusionMode"], engine.params["keywordWeight"]
    sweep = {}
    for mode in ("rrf", "score"):
        points = []
        for weight in weightGrid:
            engine.params["fusionMode"], engine.params["keywordWeight"] = mode, weight
            ranks = []
            for query, scores in zip(answerable, scoreCache):
                order = engine.rankingFor("hybrid", scores)[:ev.topK]
                ranks.append(ev.rankOfGold([engine.passageIds[i] for i in order], query["relevantPassageId"]))
            points.append({"weight": weight,
                           "recall@5": sum(r is not None for r in ranks) / len(ranks),
                           "mrr@5": sum(1.0 / r for r in ranks if r) / len(ranks)})
        sweep[mode] = points
    engine.params["fusionMode"], engine.params["keywordWeight"] = oldMode, oldWeight    # put the tuned values back
    return sweep


# ------------------------------------------------------------------ latency of each retrieval method on its own
def timeOneMethod(engine, method, text):
    start = time.perf_counter()
    if method == "keywordBaseline":
        core.rankByScore(engine.baselineIndex.score(core.rawTokens(text)), dropZeros=True)
    elif method == "keywordNormalized":
        analysis = engine.analyseQuery(text)
        core.rankByScore(engine.normalizedIndex.score(analysis["tokens"]), dropZeros=True)
    elif method == "semanticRaw":
        vector = engine.embedder.encodeQueries([core.cleanForEmbedding(text)])[0]
        core.rankByScore(engine.passageVectors @ vector)
    elif method == "semanticNormalized":
        vector = engine.embedder.encodeQueries([engine.analyseQuery(text)["denseQuery"]])[0]
        core.rankByScore(engine.passageVectors @ vector)
    else:                                                       # hybrid = every score plus the fusion step
        engine.rankingFor("hybrid", engine.scoreAll(text))
    return (time.perf_counter() - start) * 1000


def latencyPerMethod(engine, queries):
    step = max(1, len(queries) // latencyQueryCount)
    sample = queries[::step][:latencyQueryCount]
    timeOneMethod(engine, "hybrid", sample[0]["text"])          # warm-up so the first call does not skew the mean
    result = {}
    for method in methods:
        times = [timeOneMethod(engine, method, q["text"]) for q in sample]
        result[method] = {"meanMs": statistics.mean(times), "p95Ms": float(np.percentile(times, 95)), "n": len(times)}
    return result


# ------------------------------------------------------------------ everything
def buildAndSave(engine, devQueries, testQueries, embedderName, log=print):
    data = {
        "embedder": embedderName,
        "chosen": {"fusionMode": engine.params["fusionMode"], "keywordWeight": engine.params["keywordWeight"]},
        "splits": {"dev": evaluateSplit(engine, devQueries, "dev"), "test": evaluateSplit(engine, testQueries, "test")},
    }
    log("Evaluation tab data: retrieval, heatmap, confusion matrix and failures done")
    data["weightSweep"] = weightSweep(engine, devQueries)
    log("Evaluation tab data: weight sweep done")
    data["latency"] = latencyPerMethod(engine, devQueries + testQueries)
    log("Evaluation tab data: latency done")
    os.makedirs(resultsFolder, exist_ok=True)
    with open(cachePath(embedderName), "w", encoding="utf-8") as outFile:
        json.dump(data, outFile, ensure_ascii=False, indent=1)
    return data
