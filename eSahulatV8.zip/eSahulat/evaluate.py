"""
evaluate.py
Measures the system with the metrics the challenge asks for and writes an honest report.

  Recall@5, MRR@5                 -> retrieval quality (keyword vs semantic vs hybrid)
  Cross-script consistency        -> do the Urdu / Roman Urdu / English versions of one question find the same evidence?
  Abstention performance          -> does it answer what it should and refuse what it should?
  Citation support / correctness  -> is the cited passage the right one (and does the answer come from it)?
  Latency                         -> typical response time

The thresholds are tuned on the DEV data only (train_dev split + our own written negatives).
The organisers' test split is never used for tuning.

Run:   python evaluate.py                      (loads the multilingual e5 model, needs internet once)
       python evaluate.py --embedder hashing   (offline fallback)
"""
import argparse
import json
import os
import statistics
import time
from collections import defaultdict

import numpy as np

import eSahulatCore as core

resultsFolder = "results"
topK = 5
languages = ["en", "ur", "roman_ur"]


# ------------------------------------------------------------------ data
def loadAllData():
    passages = core.loadJson("data/passages.json")
    queries = core.loadJson("data/queries.json")
    devNegatives = core.loadJson("data/devNegatives.json")
    devQueries = [q for q in queries if q["split"] == "train_dev"] + devNegatives
    testQueries = [q for q in queries if q["split"] == "test"]
    return passages, devQueries, testQueries


# ------------------------------------------------------------------ fusion tuning (dev only)
def tuneFusion(engine, devQueries):
    """how should the hybrid mix keyword and semantic search? try both fusion styles and several weights, keep the best dev MRR@5"""
    answerable = [q for q in devQueries if q["answerable"]]
    scoreCache = [engine.scoreAll(q["text"]) for q in answerable]
    results = []
    for mode in ["rrf", "score"]:
        for weight in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
            engine.params["fusionMode"], engine.params["keywordWeight"] = mode, weight
            reciprocalRanks = []
            for query, scores in zip(answerable, scoreCache):
                order = engine.rankingFor("hybrid", scores)[:topK]
                rank = rankOfGold([engine.passageIds[i] for i in order], query["relevantPassageId"])
                reciprocalRanks.append(1.0 / rank if rank else 0.0)
            meanRr = round(sum(reciprocalRanks) / len(reciprocalRanks), 4)
            # ties: prefer the weight nearest 0.5 (a real mix) and plain rrf
            results.append((meanRr, -abs(weight - 0.5), mode == "rrf", mode, weight))
    best = max(results)
    for mode in ["rrf", "score"]:
        print("Fusion", mode, "-> dev MRR@5 by keyword weight:", {r[4]: r[0] for r in results if r[3] == mode})
    print("Chosen fusion:", best[3], "with keyword weight", best[4], "(dev MRR@5 %.4f)" % best[0])
    return best[3], best[4]


# ------------------------------------------------------------------ threshold tuning (dev only)
def tuneThresholds(engine, devQueries):
    print("Tuning thresholds on", len(devQueries), "dev queries ...")
    rows = []
    for query in devQueries:
        features = engine.retrievalFeatures(query["text"])
        guardCaught = engine.guardReasonFor(features) is not None
        rows.append((query["answerable"], guardCaught, features["coverage"], features["semanticScore"]))

    semanticValues = [row[3] for row in rows if row[3] is not None]
    semGrid = [0.0] if not semanticValues else list(np.linspace(min(semanticValues), max(semanticValues), 40))
    coverageGrid = [round(value, 2) for value in np.arange(0.0, 0.91, 0.05)]

    best = None
    for semThreshold in semGrid:
        for coverageThreshold in coverageGrid:
            answeredRight, answerableTotal, abstainedRight, negativeTotal = 0, 0, 0, 0
            for answerable, guardCaught, coverage, semanticScore in rows:
                passes = (not guardCaught) and coverage >= coverageThreshold and \
                         (semanticScore is None or semanticScore >= semThreshold)
                if answerable:
                    answerableTotal += 1
                    answeredRight += passes
                else:
                    negativeTotal += 1
                    abstainedRight += (not passes)
            answerRate = answeredRight / max(1, answerableTotal)
            abstainRate = abstainedRight / max(1, negativeTotal)
            balanced = 0.5 * (answerRate + abstainRate)
            # ties: prefer the setting that abstains more (an unsupported answer is worse than a refusal)
            key = (round(balanced, 6), abstainRate, coverageThreshold + semThreshold)
            if best is None or key > best[0]:
                best = (key, {"semThreshold": float(round(semThreshold, 4)), "coverageThreshold": float(coverageThreshold)},
                        answerRate, abstainRate)
    print("Best dev thresholds:", best[1], "| dev answer rate %.3f | dev abstain rate %.3f" % (best[2], best[3]))
    return best[1], {"balancedAccuracy": best[0][0], "answerRate": best[2], "abstainRate": best[3]}


# ------------------------------------------------------------------ retrieval metrics
def rankOfGold(rankedIds, goldId):
    return rankedIds.index(goldId) + 1 if goldId in rankedIds else None


def evaluateRetrieval(engine, queries, methods):
    """one pass over the queries; every method is ranked from the same scores"""
    answerable = [q for q in queries if q["answerable"]]
    perMethod = {method: {"ranks": {}, "top1": {}} for method in methods}
    for query in answerable:
        scores = engine.scoreAll(query["text"])
        for method in methods:
            order = engine.rankingFor(method, scores)[:topK]
            rankedIds = [engine.passageIds[index] for index in order]
            perMethod[method]["ranks"][query["queryId"]] = rankOfGold(rankedIds, query["relevantPassageId"])
            perMethod[method]["top1"][query["queryId"]] = rankedIds[0] if rankedIds else None

    summary = {}
    for method in methods:
        ranks = perMethod[method]["ranks"]

        def metricsFor(subset):
            rankList = [ranks[q["queryId"]] for q in subset]
            if not rankList:
                return None
            return {"n": len(rankList),
                    "recall@1": sum(r == 1 for r in rankList) / len(rankList),
                    "recall@5": sum(r is not None for r in rankList) / len(rankList),
                    "mrr@5": sum(1.0 / r for r in rankList if r) / len(rankList)}

        summary[method] = {"overall": metricsFor(answerable),
                           "byLanguage": {lang: metricsFor([q for q in answerable if q["language"] == lang])
                                          for lang in languages}}
    return summary, perMethod, answerable


def crossScriptConsistency(answerable, perMethod, methods):
    groups = defaultdict(list)
    for query in answerable:
        groups[query["relevantPassageId"]].append(query)
    usable = {gold: items for gold, items in groups.items() if len(set(q["language"] for q in items)) >= 2}
    result = {}
    for method in methods:
        allHit, sameTop1 = 0, 0
        for gold, items in usable.items():
            ranks = [perMethod[method]["ranks"][q["queryId"]] for q in items]
            tops = {perMethod[method]["top1"][q["queryId"]] for q in items}
            allHit += all(rank is not None for rank in ranks)
            sameTop1 += (len(tops) == 1)
        total = max(1, len(usable))
        result[method] = {"groups": len(usable), "allVariantsHit@5": allHit / total, "sameTop1": sameTop1 / total}
    return result


# ------------------------------------------------------------------ end-to-end answering metrics
def evaluateSystem(engine, queries, method="hybrid"):
    outcomes = []
    latencies = []
    for query in queries:
        result = engine.answerQuery(query["text"], responseLanguage="en", method=method)
        latencies.append(result["latencyMs"])
        answered = result["decision"] == "answer"
        citedId = result["evidence"][0]["passageId"] if (answered and result["evidence"]) else None
        outcomes.append({"query": query, "result": result, "answered": answered, "citedId": citedId})

    answerable = [o for o in outcomes if o["query"]["answerable"]]
    negatives = [o for o in outcomes if not o["query"]["answerable"]]
    answeredAnswerable = [o for o in answerable if o["answered"]]
    correctCitations = [o for o in answeredAnswerable if o["citedId"] == o["query"]["relevantPassageId"]]
    answeredNegatives = [o for o in negatives if o["answered"]]

    def sentenceComesFromPassage(outcome):
        # automatic check: the answer text must be made only of sentences of the cited passage
        passage = next(p for p in engine.passages if p["passageId"] == outcome["citedId"])
        body = outcome["result"]["answerText"].split(":", 1)[1].strip()
        parts = [part for part in body.replace("؛", ";").split(" ") if part]
        return all(part in passage["textEn"] or part in passage["textUr"] for part in parts)

    answeredAll = [o for o in outcomes if o["answered"]]
    supportedByConstruction = [o for o in answeredAll if sentenceComesFromPassage(o)]
    return {
        "outcomes": outcomes,
        "answerableCount": len(answerable), "negativeCount": len(negatives),
        "answeredAnswerable": len(answeredAnswerable),
        "falseAbstentions": len(answerable) - len(answeredAnswerable),
        "correctAbstentions": len(negatives) - len(answeredNegatives),
        "falseAnswers": len(answeredNegatives),
        "abstentionAccuracy": (len(answeredAnswerable) + len(negatives) - len(answeredNegatives)) / max(1, len(outcomes)),
        "answerRateOnAnswerable": len(answeredAnswerable) / max(1, len(answerable)),
        "abstainRateOnUnanswerable": (len(negatives) - len(answeredNegatives)) / max(1, len(negatives)),
        "citationCorrectness": len(correctCitations) / max(1, len(answeredAnswerable)),
        "answerTextFromCitedPassage": len(supportedByConstruction) / max(1, len(answeredAll)),
        "latencyMeanMs": statistics.mean(latencies) if latencies else None,
        "latencyMedianMs": statistics.median(latencies) if latencies else None,
        "latencyP95Ms": float(np.percentile(latencies, 95)) if latencies else None,
    }


# ------------------------------------------------------------------ report writing
def percent(value):
    return "n/a" if value is None else "%.1f%%" % (100 * value)


def retrievalTable(summary, methods):
    lines = ["| Method | n | Recall@1 | Recall@5 | MRR@5 |", "|---|---|---|---|---|"]
    for method in methods:
        overall = summary[method]["overall"]
        lines.append("| %s | %d | %s | %s | %.3f |" % (method, overall["n"], percent(overall["recall@1"]),
                                                       percent(overall["recall@5"]), overall["mrr@5"]))
    return lines


def languageTable(summary, methods):
    lines = ["| Method | en Recall@5 | ur Recall@5 | roman_ur Recall@5 | en MRR@5 | ur MRR@5 | roman_ur MRR@5 |",
             "|---|---|---|---|---|---|---|"]
    for method in methods:
        cells = [method]
        languageStats = summary[method]["byLanguage"]
        cells += [percent(languageStats[l]["recall@5"]) if languageStats[l] else "-" for l in languages]
        cells += ["%.3f" % languageStats[l]["mrr@5"] if languageStats[l] else "-" for l in languages]
        lines.append("| " + " | ".join(cells) + " |")
    return lines


def systemLines(stats, label):
    return [
        "**%s** (%d answerable, %d unanswerable/ambiguous/out-of-domain)" % (label, stats["answerableCount"], stats["negativeCount"]),
        "",
        "| Measure | Value |", "|---|---|",
        "| Answered when it should (answer rate on answerable) | %s (%d/%d) |" % (percent(stats["answerRateOnAnswerable"]), stats["answeredAnswerable"], stats["answerableCount"]),
        "| Abstained / asked clarification when it should | %s (%d/%d) |" % (percent(stats["abstainRateOnUnanswerable"]), stats["correctAbstentions"], stats["negativeCount"]),
        "| False answers (answered something it should not) | %d |" % stats["falseAnswers"],
        "| False abstentions (refused an answerable question) | %d |" % stats["falseAbstentions"],
        "| Overall decision accuracy | %s |" % percent(stats["abstentionAccuracy"]),
        "| Citation correctness (cited passage is the gold passage, among answered answerable) | %s |" % percent(stats["citationCorrectness"]),
        "| Answer text is made only of the cited passage's words (automatic check) | %s |" % percent(stats["answerTextFromCitedPassage"]),
        "| Latency mean / median / p95 (ms) | %.1f / %.1f / %.1f |" % (stats["latencyMeanMs"], stats["latencyMedianMs"], stats["latencyP95Ms"]),
        "",
    ]


def errorAnalysisLines(stats, label):
    lines = ["### %s" % label, ""]
    mistakes = []
    for outcome in stats["outcomes"]:
        query, result = outcome["query"], outcome["result"]
        if query["answerable"] and not outcome["answered"]:
            mistakes.append(("FALSE ABSTENTION", query, result, "expected %s" % query["relevantPassageId"]))
        elif query["answerable"] and outcome["citedId"] != query["relevantPassageId"]:
            mistakes.append(("WRONG PASSAGE", query, result, "expected %s, cited %s" % (query["relevantPassageId"], outcome["citedId"])))
        elif (not query["answerable"]) and outcome["answered"]:
            mistakes.append(("FALSE ANSWER", query, result, "cited %s" % outcome["citedId"]))
    if not mistakes:
        lines.append("No mistakes in this split.")
    for kind, query, result, detail in mistakes:
        lines.append("- **%s** `%s` [%s/%s] \"%s\" -> %s (reason: %s, coverage %.2f, sem %s, top5 %s)" % (
            kind, query["queryId"], query["language"], query["topic"], query["text"], detail, result["reasonCode"],
            result["coverage"], result["semanticScore"], result["retrievedPassageIds"]))
    lines.append("")
    return lines, len(mistakes)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--embedder", default="e5", choices=["e5", "hashing"])
    parser.add_argument("--model", default=core.defaultEmbeddingModel)
    arguments = parser.parse_args()
    os.makedirs(resultsFolder, exist_ok=True)

    passages, devQueries, testQueries = loadAllData()
    print("Step 1 done: loaded", len(passages), "passages,", len(devQueries), "dev queries,", len(testQueries), "test queries")

    embedder = core.makeEmbedder(arguments.embedder, arguments.model)
    engine = core.EsahulatEngine(passages, embedder)
    print("Step 2 done: engine ready with embedder", embedder.name)

    fusionMode, keywordWeight = tuneFusion(engine, devQueries)
    engine.params["fusionMode"], engine.params["keywordWeight"] = fusionMode, keywordWeight
    tunedParams, tuneInfo = tuneThresholds(engine, devQueries)
    tunedParams["keywordWeight"], tunedParams["fusionMode"] = keywordWeight, fusionMode
    engine.params.update(tunedParams)
    paramsPath = os.path.join(resultsFolder, "tunedParams.json")
    try:
        allParams = core.loadJson(paramsPath)
    except (OSError, ValueError):
        allParams = {}
    allParams[embedder.name] = tunedParams
    with open(paramsPath, "w", encoding="utf-8") as paramsFile:
        json.dump(allParams, paramsFile, indent=2)
    print("Step 3 done: thresholds tuned on dev only and saved to", paramsPath)

    methods = core.EsahulatEngine.retrievalMethods
    report = ["# E-Sahulat AI - evaluation report", "",
              "Embedder: `%s` | passages: %d | dev queries: %d | test queries: %d | top-k = %d" % (
                  embedder.name, len(passages), len(devQueries), len(testQueries), topK),
              "Tuned thresholds (dev only): `%s`  (dev balanced accuracy %.3f)" % (json.dumps(tunedParams), tuneInfo["balancedAccuracy"]),
              "", "All numbers below were measured by this script; nothing is hand-edited.", ""]
    jsonResults = {"embedder": embedder.name, "tunedParams": tunedParams}

    for label, queries in (("TEST split (organisers' held-out queries)", testQueries),
                           ("DEV split (train_dev queries + team-written negatives; used for tuning)", devQueries)):
        key = "test" if label.startswith("TEST") else "dev"
        summary, perMethod, answerable = evaluateRetrieval(engine, queries, methods)
        consistency = crossScriptConsistency(answerable, perMethod, methods)
        report += ["## Retrieval - %s" % label, ""] + retrievalTable(summary, methods) + [""]
        report += ["Per language style:", ""] + languageTable(summary, methods) + [""]
        report += ["Cross-script consistency (groups of the same question in 2+ language styles; %d groups):" % consistency["hybrid"]["groups"], "",
                   "| Method | all variants hit in top 5 | all variants share the same top-1 |", "|---|---|---|"]
        for method in methods:
            report.append("| %s | %s | %s |" % (method, percent(consistency[method]["allVariantsHit@5"]), percent(consistency[method]["sameTop1"])))
        report.append("")
        jsonResults[key + "Retrieval"] = summary
        jsonResults[key + "CrossScript"] = consistency
        print("Step 4 done: retrieval metrics for", key)

    systemStats = {}
    for label, queries, key in (("TEST split", testQueries, "test"), ("DEV split", devQueries, "dev")):
        stats = evaluateSystem(engine, queries)
        systemStats[key] = stats
        report += ["## End-to-end answering - %s (hybrid)" % label, ""] + systemLines(stats, label)
        jsonResults[key + "System"] = {k: v for k, v in stats.items() if k != "outcomes"}
        print("Step 5 done: end-to-end metrics for", key)

    report += ["## Error analysis", ""]
    for key, label in (("test", "Test split mistakes"), ("dev", "Dev split mistakes")):
        lines, count = errorAnalysisLines(systemStats[key], label)
        report += lines
        jsonResults[key + "MistakeCount"] = count

    safeName = embedder.name.replace("/", "_")                 # so runs with different models do not overwrite each other
    for reportName in ("evaluationReport_%s.md" % safeName, "evaluationReport.md"):
        with open(os.path.join(resultsFolder, reportName), "w", encoding="utf-8") as reportFile:
            reportFile.write("\n".join(report))
    with open(os.path.join(resultsFolder, "evaluationResults_%s.json" % safeName), "w", encoding="utf-8") as jsonFile:
        json.dump(jsonResults, jsonFile, indent=2, ensure_ascii=False)
    print("Step 6 done: wrote", resultsFolder + "/evaluationReport_%s.md (and evaluationReport.md)" % safeName)

    # numbers for the Evaluation tab of the app (charts, heatmap, confusion matrix, failures)
    import evalData
    evalData.buildAndSave(engine, devQueries, testQueries, embedder.name)
    print("Step 7 done: wrote", evalData.cachePath(embedder.name))
    print("\n".join(report))


if __name__ == "__main__":
    main()
