"""
app.py - Streamlit interface for Multilingual E-Sahulat AI

Run:  streamlit run app.py
Optional: set the environment variable ESAHULAT_EMBEDDER=hashing to run fully offline (weaker semantic search).

Three tabs:
  Answer         - the answer, status cards, confidence meter, what the system understood, highlighted evidence, score bars
  Evaluation     - charts from results/evalTab_<model>.json (written by evaluate.py)
  Embedding map  - PCA picture of the passages with your question as a star
Look and feel: Pakistan flag green and white, passport-stamp answer card, a small system readout strip (robotics style).
All styling lives in pageStyle / extraStyle below, the rest is plain Streamlit.
"""
import hashlib
import html
import os
import re

import numpy as np
import streamlit as st

import charts
import eSahulatCore as core
import evalData
import voice

st.set_page_config(page_title="E-Sahulat AI | Passport help desk", page_icon="🛂",
                   layout="wide", initial_sidebar_state="expanded")

# ------------------------------------------------------------------ text used by the page
languageOptions = {"Same as my question": "auto", "English": "en", "اردو": "ur", "Roman Urdu": "roman_ur"}
languageNames = {"en": "English", "ur": "Urdu", "roman_ur": "Roman Urdu"}

# headings that change with the response language
labels = {
    "en": {"answer": "Answer", "clarify": "We need a little more detail", "noAnswer": "No answer given",
           "evidence": "Where this comes from", "source": "Open the official page",
           "related": "Related general information (it does not answer your personal request)"},
    "ur": {"answer": "جواب", "clarify": "مزید تفصیل درکار ہے", "noAnswer": "جواب نہیں دیا گیا",
           "evidence": "یہ معلومات کہاں سے ہیں", "source": "سرکاری صفحہ کھولیں",
           "related": "متعلقہ عمومی معلومات (آپ کی ذاتی درخواست کا جواب نہیں)"},
    "roman_ur": {"answer": "Jawab", "clarify": "Thori aur tafseel chahiye", "noAnswer": "Jawab nahi diya gaya",
                 "evidence": "Ye maloomat kahan se hain", "source": "Sarkari page kholein",
                 "related": "Mutaliqa aam maloomat (aap ki zaati darkhwast ka jawab nahi)"},
}

# plain-words version of the internal reason codes
reasonWords = {
    "supported": "The best passage covers the question well enough to quote.",
    "noEvidence": "No passage matched strongly enough, so nothing is quoted.",
    "outOfDomain": "Nothing in the question matches the passport topics we cover.",
    "injection": "The message tried to change the rules, so it was not answered.",
    "unsafe": "The request looked unsafe, so it was not answered.",
    "timeSensitive": "The answer depends on today's situation, which the sources cannot confirm.",
    "noGuarantee": "No source can guarantee an outcome for one person.",
    "personalStatus": "Needs access to your own application, which this tool does not have.",
    "personalTiming": "Needs your own application details, which this tool does not have.",
    "unsupportedAction": "This tool gives information only. It cannot book or submit anything.",
    "conflict": "The question mixes things the sources treat differently.",
    "ambiguousFee": "No fee table is in the sources, and the question did not say which fee.",
    "vague": "The question is too short to pick one topic.",
}
scoreReasons = {"supported", "noEvidence", "outOfDomain"}      # every other reason code means a rule fired before scoring

methodNames = {"keywordBaseline": "BM25 (plain)", "keywordNormalized": "BM25 + normalization",
               "semanticRaw": "Semantic (plain)", "semanticNormalized": "Semantic + normalization", "hybrid": "Hybrid"}

exampleQuestions = [
    "پاسپورٹ کی تجدید کے لیے کون سی دستاویزات درکار ہیں؟",
    "Which documents are required to renew a passport?",
    "Passport renewal ke liye online apply karna hota hai ya office jana hota hai?",
    "pasport renu karwana hy",
    "I need to replace my expired passport. Where should I start?",
    "How long does a normal passport take?",
    "What is the guaranteed processing time for my individual application?",
    "How much does it cost?",
    "Who will win the next cricket world cup?",
]

# ------------------------------------------------------------------ styling
pageStyle = """
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&family=Noto+Nastaliq+Urdu:wght@400;600&display=swap');

:root {
  --flagGreen: #01411C;
  --deepGreen: #062B1A;
  --leaf: #1F7A4D;
  --mint: #E8F0EA;
  --paper: #FFFFFF;
  --ink: #14241B;
  --muted: #566A5E;
  --line: #C9D8CD;
  --brass: #A67A1C;
  --amberText: #7A4A00;
  --amberFill: #FFF2D6;
  --stopText: #6A2A24;
  --stopFill: #F6E7E4;
}

html, body, .stApp { background: var(--mint) !important; color: var(--ink); font-family: 'IBM Plex Sans', sans-serif; }
/* faint engineering-paper grid behind everything */
.stApp { background-image: linear-gradient(rgba(1,65,28,.045) 1px, transparent 1px), linear-gradient(90deg, rgba(1,65,28,.045) 1px, transparent 1px); background-size: 28px 28px; }
header[data-testid="stHeader"], #MainMenu, footer { visibility: hidden; height: 0; }
.block-container { max-width: 1080px; padding: 0 16px 48px 16px !important; }

/* ---- top bar */
.topBar { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px;
  background: var(--flagGreen); color: #fff; padding: 14px 20px; margin-top: 16px; border-radius: 6px 6px 0 0; }
.brand { display: flex; align-items: center; gap: 12px; }
.brandName { font-size: 1.35rem; font-weight: 600; letter-spacing: .01em; line-height: 1.1; }
.brandSub { font-size: .86rem; opacity: .85; }
.statusChip { font-family: 'IBM Plex Mono', monospace; font-size: .78rem; background: rgba(255,255,255,.1);
  border: 1px solid rgba(255,255,255,.28); padding: 6px 10px; border-radius: 3px; display: flex; align-items: center; gap: 8px; }
.statusDot { width: 8px; height: 8px; border-radius: 50%; background: #7CE3A1; box-shadow: 0 0 0 3px rgba(124,227,161,.25); }
/* strip of small diamonds under the bar, a nod to truck-art borders */
.borderStrip { height: 12px; margin-bottom: 22px; border-radius: 0 0 6px 6px;
  background-color: var(--deepGreen);
  background-image: linear-gradient(45deg, var(--brass) 25%, transparent 25%, transparent 75%, var(--brass) 75%),
                    linear-gradient(45deg, var(--brass) 25%, transparent 25%, transparent 75%, var(--brass) 75%);
  background-size: 12px 12px; background-position: 0 0, 6px 6px; opacity: .95; }

.introLine { font-size: 1.05rem; max-width: 62ch; color: var(--ink); margin: 0 0 14px 0; line-height: 1.55; }

/* ---- inputs */
div[data-testid="stTextInput"] input { background: var(--paper); border: 2px solid var(--flagGreen); border-radius: 4px;
  padding: 14px 16px; font-size: 1.1rem; color: var(--ink); font-family: 'IBM Plex Sans', 'Noto Nastaliq Urdu', sans-serif; }
div[data-testid="stTextInput"] input:focus { outline: 3px solid rgba(166,122,28,.55); outline-offset: 1px; border-color: var(--flagGreen); }
div[data-testid="stTextInput"] label p, div[data-testid="stRadio"] label p, div[data-testid="stSelectbox"] label p { font-weight: 600; color: var(--flagGreen); font-size: .92rem; }
div[data-testid="stRadio"] div[role="radiogroup"] { gap: 6px; flex-wrap: wrap; }
div[data-testid="stRadio"] label[data-baseweb="radio"] { background: var(--paper); border: 1px solid var(--line); border-radius: 3px; padding: 6px 12px; }
div[data-testid="stRadio"] label[data-baseweb="radio"]:has(input:checked) { border-color: var(--flagGreen); background: #DDEBE1; }
div[data-testid="stSelectbox"] div[data-baseweb="select"] > div { background: var(--paper); border: 1px solid var(--line); border-radius: 3px; }

/* example question buttons */
div[data-testid="stButton"] button { width: 100%; text-align: left; justify-content: flex-start; background: var(--paper); color: var(--ink);
  border: 1px solid var(--line); border-left: 4px solid var(--leaf); border-radius: 3px; padding: 8px 12px; font-size: .9rem; line-height: 1.4; min-height: 3.1em; }
div[data-testid="stButton"] button:hover { border-color: var(--flagGreen); border-left-color: var(--brass); color: var(--flagGreen); }
div[data-testid="stButton"] button:focus-visible { outline: 3px solid rgba(166,122,28,.6); }
div[data-testid="stButton"] button p { text-align: left; }

/* ---- system readout strip */
.readout { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; margin: 22px 0 18px 0; background: var(--deepGreen);
  border-radius: 4px; overflow: hidden; border: 1px solid var(--deepGreen); }
.readCell { padding: 12px 14px; color: #D8EBDD; border-right: 1px solid rgba(255,255,255,.14); min-width: 0; }
.readCell:last-child { border-right: 0; }
.readName { font-size: .8rem; color: #9FC4AB; margin-bottom: 4px; display: flex; align-items: center; gap: 6px; }
.readLamp { width: 7px; height: 7px; border-radius: 50%; background: #3F5B49; flex: none; }
.readValue { font-family: 'IBM Plex Mono', monospace; font-size: .92rem; color: #fff; overflow-wrap: anywhere; }
.readNote { font-size: .78rem; color: #9FC4AB; margin-top: 2px; }
/* the one animated moment: the four lamps switch on in order after a question is sent */
.readout.live .readLamp { animation: lampOn .4s ease forwards; }
.readout.live .readCell:nth-child(1) .readLamp { animation-delay: .05s; }
.readout.live .readCell:nth-child(2) .readLamp { animation-delay: .3s; }
.readout.live .readCell:nth-child(3) .readLamp { animation-delay: .55s; }
.readout.live .readCell:nth-child(4) .readLamp { animation-delay: .8s; }
@keyframes lampOn { to { background: #7CE3A1; box-shadow: 0 0 6px 1px rgba(124,227,161,.7); } }
.readout.live.warnEnd .readCell:nth-child(4) .readLamp { --x: 1; animation-name: lampWarn; }
.readout.live.stopEnd .readCell:nth-child(4) .readLamp { animation-name: lampStop; }
@keyframes lampWarn { to { background: #F2B544; box-shadow: 0 0 6px 1px rgba(242,181,68,.7); } }
@keyframes lampStop { to { background: #E8847A; box-shadow: 0 0 6px 1px rgba(232,132,122,.7); } }

/* ---- result card */
.resultCard { background: var(--paper); border: 1px solid var(--line); border-left: 8px solid var(--flagGreen); border-radius: 4px; padding: 20px 22px; margin-bottom: 14px; }
.resultCard.warn { border-left-color: #C98A12; background: #FFFCF4; }
.resultCard.stop { border-left-color: #A9453B; background: #FFFAF9; }
.resultHead { display: flex; flex-wrap: wrap; align-items: center; gap: 12px; margin-bottom: 10px; }
.resultTitle { font-size: 1.25rem; font-weight: 600; margin: 0; }
.stamp { font-size: .8rem; font-weight: 600; color: var(--flagGreen); border: 2px solid var(--flagGreen); border-radius: 50px; padding: 3px 12px; transform: rotate(-2deg); background: #fff; }
.stamp.warn { color: var(--amberText); border-color: #C98A12; }
.stamp.stop { color: var(--stopText); border-color: #A9453B; }
.answerBody { font-size: 1.18rem; line-height: 1.75; max-width: 70ch; margin: 6px 0 14px 0; }
.rtl { direction: rtl; text-align: right; font-family: 'Noto Nastaliq Urdu', serif; line-height: 2.3; font-size: 1.25rem; }
.citeRow { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.citeChip { font-family: 'IBM Plex Mono', monospace; font-size: .8rem; background: var(--mint); border: 1px solid var(--line); padding: 3px 8px; border-radius: 3px; overflow-wrap: anywhere; }
.openLink a { display: inline-block; background: var(--flagGreen); color: #fff !important; text-decoration: none; padding: 7px 14px; border-radius: 3px; font-weight: 500; font-size: .92rem; }
.openLink a:hover { background: var(--leaf); }
.openLink a:focus-visible { outline: 3px solid rgba(166,122,28,.7); outline-offset: 2px; }

.sectionTitle { font-size: 1.05rem; font-weight: 600; color: var(--flagGreen); margin: 22px 0 6px 0; }
.passageText { background: var(--paper); border: 1px solid var(--line); border-radius: 4px; padding: 14px 16px; font-size: 1.05rem; line-height: 1.7; max-width: 75ch; }
.noteSmall { font-size: .85rem; color: var(--muted); margin-top: 6px; }

/* ---- engineer panel */
.meterRow { display: grid; grid-template-columns: 11rem 1fr 4rem; align-items: center; gap: 10px; margin: 6px 0; font-size: .9rem; }
.meterTrack { height: 10px; background: #DCE7DF; border-radius: 2px; overflow: hidden; }
.meterFill { height: 100%; background: var(--leaf); }
.meterNum { font-family: 'IBM Plex Mono', monospace; text-align: right; }
.idChips { display: flex; flex-wrap: wrap; gap: 6px; margin: 4px 0 8px 0; }
.idChip { font-family: 'IBM Plex Mono', monospace; font-size: .82rem; border: 1px solid var(--line); background: var(--paper); padding: 2px 8px; border-radius: 3px; }
.idChip.first { border-color: var(--flagGreen); background: #DDEBE1; font-weight: 500; }
div[data-testid="stExpander"] { background: var(--paper); border: 1px solid var(--line); border-radius: 4px; }
div[data-testid="stTabs"] button[role="tab"] { font-weight: 500; }

.footerNote { margin-top: 30px; padding-top: 12px; border-top: 1px solid var(--line); font-size: .85rem; color: var(--muted); max-width: 80ch; line-height: 1.55; }

@media (max-width: 760px) {
  .readout { grid-template-columns: 1fr 1fr; }
  .readCell:nth-child(2) { border-right: 0; }
  .readCell:nth-child(-n+2) { border-bottom: 1px solid rgba(255,255,255,.14); }
  .meterRow { grid-template-columns: 8rem 1fr 3.5rem; }
}
@media (prefers-reduced-motion: reduce) {
  .readout.live .readLamp { animation-duration: .01s; animation-delay: 0s !important; }
}
</style>
"""

extraStyle = """
<style>
/* ---- badges under the readout */
.badgeRow { display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 16px 0; }
.badge { display: inline-flex; align-items: center; gap: 6px; border: 1px solid var(--line); background: var(--paper); padding: 4px 11px; border-radius: 50px; font-size: .88rem; }
.badge b { color: var(--flagGreen); font-weight: 600; }

/* ---- tabs */
div[data-testid="stTabs"] [role="tablist"] { border-bottom: 2px solid var(--flagGreen); gap: 4px; }
div[data-testid="stTabs"] button[role="tab"] { font-size: 1rem; padding: 8px 16px; }
div[data-testid="stTabs"] button[role="tab"][aria-selected="true"] { color: var(--flagGreen); }

/* ---- sidebar history */
section[data-testid="stSidebar"] { background: #DDEBE1; border-right: 1px solid var(--line); }
.sideTitle { font-weight: 600; color: var(--flagGreen); margin: 4px 0 8px 0; }
.sideEmpty { font-size: .88rem; color: var(--muted); line-height: 1.5; }

/* ---- status cards and gauge */
.statusRow { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 10px 0 6px 0; }
.statusCard { background: var(--paper); border: 1px solid var(--line); border-top: 5px solid #9DB3A5; padding: 10px 12px; border-radius: 3px; min-width: 0; }
.statusCard.ok { border-top-color: var(--leaf); }
.statusCard.warn { border-top-color: #C98A12; }
.statusCard.stop { border-top-color: #A9453B; }
.scTitle { font-size: .85rem; font-weight: 600; color: var(--muted); }
.scBig { font-size: 1.2rem; font-weight: 600; margin: 2px 0; overflow-wrap: anywhere; }
.scSmall { font-size: .84rem; color: var(--muted); line-height: 1.4; }
.gauge { background: var(--paper); border: 1px solid var(--line); padding: 12px 14px; border-radius: 3px; margin: 10px 0; }
.gaugeTop { display: flex; flex-wrap: wrap; justify-content: space-between; gap: 6px 16px; margin-bottom: 8px; }
.gaugeHead { font-weight: 600; }
.gaugeNote { font-size: .84rem; color: var(--muted); max-width: 60ch; }
.gaugeTrack { position: relative; height: 16px; background: #DCE7DF; border-radius: 2px; }
.gaugeFill { height: 100%; border-radius: 2px; }
.gaugeOk { background: var(--leaf); }
.gaugeLow { background: #C96B5E; }
.gaugeIdle { background: #9DB3A5; }
.gaugeTick { position: absolute; left: 50%; top: -4px; bottom: -4px; width: 3px; background: var(--ink); }
.gaugeScale { display: flex; justify-content: space-between; font-size: .78rem; color: var(--muted); margin-top: 4px; }

/* ---- what the system understood */
.normGrid { display: grid; grid-template-columns: 8rem 1fr; gap: 10px 14px; background: var(--paper); border: 1px solid var(--line); padding: 12px 14px; border-radius: 3px; }
.normLabel { font-weight: 600; color: var(--flagGreen); }
.normValue { overflow-wrap: anywhere; line-height: 1.7; }
.tokChip { display: inline-block; font-family: 'IBM Plex Mono', monospace; font-size: .85rem; border: 1px solid var(--line); padding: 1px 7px; margin: 2px 4px 2px 0; border-radius: 3px; background: #fff; }
.tokChip.concept { background: #DDEBE1; border-color: var(--leaf); }

/* ---- highlighted evidence */
.passageText mark { background: #F6E3A3; color: var(--ink); padding: 0 2px; border-radius: 2px; }
.passageText .quoted { background: #DDEBE1; border-bottom: 2px solid var(--flagGreen); }

/* ---- score bars per passage */
.sbLegendRow { display: flex; flex-wrap: wrap; gap: 6px 16px; font-size: .86rem; margin: 4px 0 8px 0; }
.sbSwatch { display: inline-block; width: 12px; height: 12px; margin-right: 6px; border-radius: 2px; vertical-align: -1px; }
.sb0 { background: var(--flagGreen); }
.sb1 { background: var(--brass); }
.sb2 { background: #6E7F75; }
.sbRow { display: grid; grid-template-columns: minmax(9rem, 1fr) 2fr; gap: 10px; padding: 8px 10px; border-left: 5px solid transparent; background: var(--paper); border: 1px solid var(--line); margin-bottom: 4px; border-radius: 3px; }
.sbRow { border-left: 5px solid var(--line); }
.sbRow.sbTop { border-left-color: var(--flagGreen); }
.sbLabel { font-size: .9rem; line-height: 1.35; overflow-wrap: anywhere; }
.sbLine { display: flex; align-items: center; gap: 8px; margin: 2px 0; }
.sbTrack { flex: 1; height: 8px; background: #DCE7DF; border-radius: 2px; overflow: hidden; }
.sbFill { height: 100%; }
.sbText { font-family: 'IBM Plex Mono', monospace; font-size: .76rem; width: 9.5rem; color: var(--muted); }

/* ---- charts */
.chartSvg { width: 100%; height: auto; display: block; background: #fff; border: 1px solid var(--line); border-radius: 4px; }
.svgText { font-family: 'IBM Plex Sans', sans-serif; font-size: 12px; fill: var(--ink); }
.svgText.small { font-size: 11px; fill: var(--muted); }
.svgText.tiny { font-size: 10px; }
.svgGrid { stroke: #DCE7DF; stroke-width: 1; }
.svgFrame { fill: #fff; stroke: var(--line); }
.barA { fill: var(--flagGreen); }
.barB { fill: var(--brass); }
.lineA { fill: none; stroke: var(--flagGreen); stroke-width: 2.5; }
.lineB { fill: none; stroke: var(--brass); stroke-width: 2.5; stroke-dasharray: 6 4; }
.dotA { fill: var(--flagGreen); }
.dotB { fill: var(--brass); }
.markerLine { stroke: #8A3B31; stroke-width: 1.5; stroke-dasharray: 4 4; }
.scatterOther { fill: #9DB3A5; }
.scatterTop { fill: var(--leaf); }
.scatterFirst { fill: var(--flagGreen); stroke: #fff; stroke-width: 2; }
.starQuery { fill: var(--brass); stroke: var(--deepGreen); stroke-width: 1.5; }

/* ---- heatmap and confusion matrix */
.hmGrid { display: grid; grid-template-columns: minmax(10rem, 1.8fr) repeat(3, 1fr); gap: 3px; font-size: .84rem; }
.hmHead { font-weight: 600; color: var(--flagGreen); padding: 4px 6px; }
.hmLabel { padding: 5px 8px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; background: var(--paper); border: 1px solid var(--line); }
.hmCell { padding: 5px 6px; text-align: center; border-radius: 2px; font-weight: 500; }
.hmTop1 { background: #1F7A4D; color: #fff; }
.hmTop5 { background: #F2D58C; color: #4D3500; }
.hmMiss { background: #B5483C; color: #fff; }
.hmNone { background: #E9EEEA; color: #6B7B71; font-weight: 400; }
.cmGrid { display: grid; grid-template-columns: 11rem 1fr 1fr; gap: 4px; max-width: 640px; }
.cmHead { font-weight: 600; color: var(--flagGreen); padding: 4px 6px; font-size: .9rem; }
.cmSide { padding: 10px; background: var(--paper); border: 1px solid var(--line); font-weight: 600; font-size: .92rem; }
.cmSide span { display: block; font-weight: 400; color: var(--muted); font-size: .8rem; }
.cmCell { padding: 14px 10px; text-align: center; border-radius: 3px; border: 1px solid var(--line); }
.cmCell b { display: block; font-size: 1.9rem; line-height: 1.1; }
.cmCell span { font-size: .84rem; }
.cmGood { background: #DDEBE1; border-color: var(--leaf); }
.cmBad { background: var(--stopFill); border-color: #A9453B; }
.cmZero { background: #F3F6F4; color: var(--muted); }

@media (max-width: 760px) {
  .statusRow { grid-template-columns: 1fr 1fr; }
  .sbRow { grid-template-columns: 1fr; }
  .normGrid { grid-template-columns: 1fr; gap: 2px; }
  .cmGrid { grid-template-columns: 7rem 1fr 1fr; }
}
</style>
"""

# small crescent and star badge drawn with svg (white tile, green crescent, star sits in the opening)
logoSvg = (
    "<svg width='42' height='42' viewBox='0 0 48 48' aria-hidden='true'>"
    "<rect width='48' height='48' rx='6' fill='#fff'/>"
    "<circle cx='22' cy='24' r='13' fill='#01411C'/><circle cx='27' cy='22' r='11' fill='#fff'/>"
    "<polygon points='32,13 33.4,17.2 37.8,17.3 34.3,20 35.6,24.2 32,21.7 28.4,24.2 29.7,20 26.2,17.3 30.6,17.2' fill='#01411C'/>"
    "</svg>"
)


# ------------------------------------------------------------------ engine loading
@st.cache_resource(show_spinner="Loading knowledge base and models (first run downloads the model)...")
def loadEngine(embedderKind, modelName):
    passages = core.loadJson("data/passages.json")
    embedder = core.makeEmbedder(embedderKind, modelName)
    tunedParams = core.loadTunedParams("results/tunedParams.json", embedder.name)
    return core.EsahulatEngine(passages, embedder, tunedParams), embedder.name, tunedParams is not None


@st.cache_resource(show_spinner="Loading the speech model (first use downloads it)...")
def loadWhisper(sizeName):
    return voice.loadModel(sizeName)


whisperSize = os.environ.get("ESAHULAT_WHISPER", "small")        # tiny / base / small: bigger = more accurate, slower


embedderKind = os.environ.get("ESAHULAT_EMBEDDER", "e5")
modelName = os.environ.get("ESAHULAT_MODEL", core.defaultEmbeddingModel)   # e.g. intfloat/multilingual-e5-base
engine, embedderName, usingTunedParams = loadEngine(embedderKind, modelName)


# ------------------------------------------------------------------ small html helpers
def esc(text):
    return html.escape(str(text if text is not None else ""))


def scriptOf(text):
    # which writing system did the person type in?
    hasUrdu = re.search(r"[؀-ۿ]", text) is not None
    hasLatin = re.search(r"[A-Za-z]", text) is not None
    if hasUrdu and hasLatin:
        return "Urdu and Latin letters mixed"
    return "Urdu script, right to left" if hasUrdu else "Latin letters"


def textBlock(text, isUrdu, cssClass="passageText"):
    # one box of text; Urdu goes right-to-left with a Nastaliq font
    extra = " rtl" if isUrdu else ""
    return "<div class='%s%s'>%s</div>" % (cssClass, extra, esc(text))


def highlightedBlock(text, isUrdu, queryTokenSet, quotedSentences):
    """passage text where words that matched the question are marked, and sentences quoted in the answer are shaded"""
    quoteRanges = []
    for sentence in quotedSentences:
        start = text.find(sentence)
        if start >= 0:
            quoteRanges.append((start, start + len(sentence)))
    pieces = []
    for match in re.finditer(r"\s+|\S+", text):
        piece, position = match.group(), match.start()
        shown = esc(piece)
        if not piece.isspace():
            wordTokens = core.toSearchTokens(core.normalizeForSearch(piece))[0]
            if any(token in queryTokenSet for token in wordTokens):
                shown = "<mark>%s</mark>" % shown
        if any(start <= position < end for start, end in quoteRanges):
            shown = "<span class='quoted'>%s</span>" % shown
        pieces.append(shown)
    return "<div class='passageText%s'>%s</div>" % (" rtl" if isUrdu else "", "".join(pieces))


def statusCard(title, state, big, small):
    return ("<div class='statusCard %s'><div class='scTitle'>%s</div><div class='scBig'>%s</div><div class='scSmall'>%s</div></div>"
            % (state, esc(title), esc(big), esc(small)))


def readoutHtml(result, detectedLanguage):
    # four cells: language, search, evidence check, outcome. With no result yet they all sit idle.
    if result is None:
        cells = [("Language", "waiting", "ask a question above"), ("Search", "waiting", "%d passages ready" % len(engine.passages)),
                 ("Evidence check", "waiting", "none yet"), ("Outcome", "waiting", "none yet")]
        liveClass = ""
    else:
        outcomeWords = {"answer": "answered", "clarify": "asked for detail"}
        coverage = float(result.get("coverage") or 0)
        semantic = float(result.get("semanticScore") or 0)
        cells = [
            ("Language", languageNames[detectedLanguage], "detected from your words"),
            ("Search", "%d passages" % len(engine.passages), "%s, %.0f ms" % (result["method"], result["latencyMs"])),
            ("Evidence check", "kw %.2f / sem %.2f" % (coverage, semantic), "keyword and meaning match"),
            ("Outcome", outcomeWords.get(result["decision"], "withheld"), reasonWords.get(result["reasonCode"], result["reasonCode"])),
        ]
        endClass = {"answer": "", "clarify": " warnEnd"}.get(result["decision"], " stopEnd")
        liveClass = " live" + endClass
    cellHtml = "".join(
        "<div class='readCell'><div class='readName'><span class='readLamp'></span>%s</div>"
        "<div class='readValue'>%s</div><div class='readNote'>%s</div></div>" % (esc(n), esc(v), esc(note))
        for n, v, note in cells)
    return "<div class='readout%s' role='status'>%s</div>" % (liveClass, cellHtml)


def showWide(table):
    # newer Streamlit uses width="stretch", older versions use use_container_width
    try:
        st.dataframe(table, width="stretch", hide_index=True)
    except Exception:
        st.dataframe(table, use_container_width=True, hide_index=True)


# ------------------------------------------------------------------ page header
st.markdown(pageStyle + extraStyle, unsafe_allow_html=True)
st.markdown(
    "<div class='topBar'><div class='brand'>%s<div><div class='brandName'>E-Sahulat</div>"
    "<div class='brandSub'>Passport help desk &nbsp;|&nbsp; پاسپورٹ معلومات مرکز</div></div></div>"
    "<div class='statusChip'><span class='statusDot'></span>online, %d official passages</div></div>"
    "<div class='borderStrip'></div>" % (logoSvg, len(engine.passages)),
    unsafe_allow_html=True)

st.markdown("<p class='introLine'>Ask about Pakistani passports in Urdu, Roman Urdu or English. "
            "Every answer is quoted from an official DGI&amp;P page and shows its source. "
            "If the sources do not cover your question, we say so instead of guessing.</p>", unsafe_allow_html=True)

# ------------------------------------------------------------------ question area
if "questionText" not in st.session_state:
    st.session_state["questionText"] = ""
if "history" not in st.session_state:
    st.session_state["history"] = []


def useExample(exampleText):
    # runs before the page redraws, so the text box shows the chosen example
    st.session_state["questionText"] = exampleText


def clearHistory():
    st.session_state["history"] = []
    st.session_state["lastLogged"] = None


settingsLeft, settingsRight = st.columns([3, 2])
with settingsLeft:
    languageName = st.radio("Answer language", list(languageOptions), horizontal=True)
with settingsRight:
    method = st.selectbox("Search method", ["hybrid", "keywordNormalized", "semanticNormalized", "keywordBaseline"],
                          help="hybrid = keyword search and meaning search combined (the best one in our tests)")
chosenLanguage = languageOptions[languageName]

# ---------- microphone: record, transcribe locally, drop the text into the question box
with st.expander("Speak your question (processed on this machine, nothing is sent to an online service)"):
    speechChoice = st.radio("Language you will speak", list(voice.speechLanguages), horizontal=True, key="speechLanguage")
    if not hasattr(st, "audio_input"):
        st.markdown("<div class='noteSmall'>This Streamlit version has no microphone widget. Run <code>pip install -U streamlit</code>.</div>",
                    unsafe_allow_html=True)
    else:
        recording = st.audio_input("Press the microphone, speak, then press stop", key="micRecording")
        if recording is not None:
            audioBytes = recording.getvalue()
            audioId = hashlib.md5(audioBytes).hexdigest()
            if st.session_state.get("lastAudioId") != audioId:          # only transcribe a new recording, not on every redraw
                st.session_state["lastAudioId"] = audioId
                speechModel, speechError = loadWhisper(whisperSize)
                if speechModel is None:
                    st.session_state["voiceNote"] = {"text": "", "language": None, "seconds": 0.0, "error": speechError}
                else:
                    with st.spinner("Listening..."):
                        st.session_state["voiceNote"] = voice.transcribe(speechModel, audioBytes, voice.speechLanguages[speechChoice])
                heardNow = st.session_state["voiceNote"]
                if heardNow["text"]:
                    st.session_state["questionText"] = heardNow["text"]    # safe: the text box is created further down
        heard = st.session_state.get("voiceNote")
        if heard and heard["error"]:
            st.markdown("<div class='noteSmall'>%s</div>" % esc(heard["error"]), unsafe_allow_html=True)
        elif heard and not heard["text"]:
            st.markdown("<div class='noteSmall'>No speech was heard. Try again, closer to the microphone.</div>", unsafe_allow_html=True)
        elif heard:
            st.markdown("<div class='noteSmall'>Heard (%s, %.1f s): <b dir='auto'>%s</b>. Edit it in the box below if a word is wrong.</div>"
                        % (esc(heard["language"]), heard["seconds"], esc(heard["text"])), unsafe_allow_html=True)

questionText = st.text_input("Your question", key="questionText",
                             placeholder="e.g. Passport renew karwanay ke liye online apply karna hota hai?")

with st.expander("Not sure what to ask? Try an example", expanded=not questionText.strip()):
    exampleColumns = st.columns(3)
    for number, example in enumerate(exampleQuestions):
        with exampleColumns[number % 3]:
            st.button(example, key="example%d" % number, on_click=useExample, args=(example,))

# ------------------------------------------------------------------ run the question
hasQuestion = bool(questionText.strip())
result = None
detectedLanguage = core.detectQueryLanguage(questionText) if hasQuestion else "en"
responseLanguage = detectedLanguage if chosenLanguage == "auto" else chosenLanguage
analysis, scores = None, None
if hasQuestion:
    result = engine.answerQuery(questionText, responseLanguage, method)
    analysis = engine.analyseQuery(questionText)
    scores = engine.scoreAll(questionText, analysis)
    signature = (questionText, method, responseLanguage)
    if st.session_state.get("lastLogged") != signature:           # log each new question once, not on every redraw
        st.session_state["history"].append({"text": questionText, "decision": result["decision"]})
        st.session_state["lastLogged"] = signature

# ------------------------------------------------------------------ sidebar: query history
st.sidebar.markdown("<div class='sideTitle'>Recent questions</div>", unsafe_allow_html=True)
recent = st.session_state["history"][-12:][::-1]
if not recent:
    st.sidebar.markdown("<div class='sideEmpty'>Questions you ask will be listed here. Click one to ask it again.</div>", unsafe_allow_html=True)
for position, item in enumerate(recent):
    prefix = {"answer": "Answered", "clarify": "Needs detail"}.get(item["decision"], "Withheld")
    shortText = item["text"] if len(item["text"]) <= 44 else item["text"][:43] + "..."
    st.sidebar.button("%s: %s" % (prefix, shortText), key="history%d" % position, on_click=useExample, args=(item["text"],))
if recent:
    st.sidebar.button("Clear history", key="clearHistory", on_click=clearHistory)

# ------------------------------------------------------------------ readout strip and badges
st.markdown(readoutHtml(result, detectedLanguage), unsafe_allow_html=True)
if hasQuestion:
    st.markdown("<div class='badgeRow'><span class='badge'>Language <b>%s</b></span><span class='badge'>Script <b>%s</b></span>"
                "<span class='badge'>Answering in <b>%s</b></span><span class='badge'>Method <b>%s</b></span></div>"
                % (esc(languageNames[detectedLanguage]), esc(scriptOf(questionText)), esc(languageNames[responseLanguage]),
                   esc(methodNames.get(method, method))), unsafe_allow_html=True)

tabAnswer, tabEvaluation, tabMap = st.tabs(["Answer", "Evaluation", "Embedding map"])

# ====================================================================== ANSWER TAB
with tabAnswer:
    if result is None:
        st.markdown("<div class='resultCard'><h2 class='resultTitle'>Ask your first question</h2>"
                    "<div class='answerBody'>Type a question above, or open the examples. You will see the answer, the official source, "
                    "how sure the system is, and exactly which words it matched.</div></div>", unsafe_allow_html=True)
    else:
        labelSet = labels[responseLanguage]
        isUrdu = responseLanguage == "ur"
        decision = result["decision"]
        styleName = {"answer": "", "clarify": "warn"}.get(decision, "stop")
        stampWords = {"answer": "From an official source", "clarify": "Needs detail"}.get(decision, "Not answered")
        heading = {"answer": labelSet["answer"], "clarify": labelSet["clarify"]}.get(decision, labelSet["noAnswer"])
        bodyText = result["answerText"] if decision == "answer" else result["message"]
        topEvidence = result["evidence"][0] if result["evidence"] else None

        # main card: heading, stamp, the answer text, then the citation row
        cardHtml = ("<div class='resultCard %s'><div class='resultHead'><h2 class='resultTitle'>%s</h2>"
                    "<span class='stamp %s'>%s</span></div>%s" % (styleName, esc(heading), styleName, esc(stampWords),
                                                                  textBlock(bodyText, isUrdu, "answerBody")))
        if decision == "answer" and topEvidence:
            cardHtml += ("<div class='citeRow'><span class='citeChip'>passage %s</span><span class='citeChip'>%s</span>"
                         "<span class='openLink'><a href='%s' target='_blank' rel='noopener'>%s</a></span></div>"
                         % (esc(topEvidence["passageId"]), esc(topEvidence["docId"]),
                            esc(topEvidence["sourceUrl"]), esc(labelSet["source"])))
        cardHtml += "</div>"
        st.markdown(cardHtml, unsafe_allow_html=True)

        # ---------- confidence meter and status cards
        coverage = float(result.get("coverage") or 0)
        semantic = result.get("semanticScore")
        coverageLine = float(engine.params["coverageThreshold"])
        semanticLine = float(engine.params["semThreshold"])
        ruleFired = result["reasonCode"] not in scoreReasons
        ratios = []
        if coverageLine > 0:
            ratios.append(coverage / coverageLine)
        if semanticLine > 0 and semantic is not None:
            ratios.append(semantic / semanticLine)
        strength = min(ratios) if ratios else 1.0
        if ruleFired:
            gaugeNote = "A safety rule decided this before the scores were used. The scores are shown for information."
        else:
            gaugeNote = ("How far the best passage sits above (or below) the lowest score that is allowed to answer. "
                         "It is a margin, not a probability.")
        st.markdown("<div class='sectionTitle'>How sure is the system?</div>", unsafe_allow_html=True)
        st.markdown(charts.gaugeHtml(strength, "Evidence strength: %.0f%% of the answer line" % (100 * strength), gaugeNote, neutral=ruleFired), unsafe_allow_html=True)

        ruleState = "ok" if not ruleFired else ("warn" if decision == "clarify" else "stop")
        cards = [
            statusCard("Safety rules", ruleState, "Passed" if not ruleFired else "Stopped here",
                       "No rule matched your question." if not ruleFired else reasonWords.get(result["reasonCode"], result["reasonCode"])),
            statusCard("Keyword match", "idle" if ruleFired else ("ok" if coverage >= coverageLine else "stop"), "%.2f" % coverage,
                       "answer line %.2f" % coverageLine if not ruleFired else "not used, a rule decided first"),
            statusCard("Meaning match", "idle" if (ruleFired or semantic is None or semanticLine <= 0) else ("ok" if semantic >= semanticLine else "stop"),
                       "n/a" if semantic is None else "%.2f" % semantic,
                       "answer line %.2f" % semanticLine if (not ruleFired and semanticLine > 0) else "not used here"),
            statusCard("Citation", "ok" if decision == "answer" else "idle",
                       ("Passage " + topEvidence["passageId"]) if (decision == "answer" and topEvidence) else "Nothing cited",
                       topEvidence["docId"] if (decision == "answer" and topEvidence) else "No answer was given, so no source is claimed."),
        ]
        st.markdown("<div class='statusRow'>%s</div>" % "".join(cards), unsafe_allow_html=True)

        # ---------- what the system understood (normalization view)
        st.markdown("<div class='sectionTitle'>What the system understood</div>", unsafe_allow_html=True)
        chipHtml = "".join("<span class='tokChip concept'>%s</span>" % esc(token[2:]) if token.startswith("c_")
                           else "<span class='tokChip'>%s</span>" % esc(token) for token in analysis["tokens"]) or "<span class='scSmall'>no search terms left</span>"
        st.markdown("<div class='normGrid'><div class='normLabel'>You typed</div><div class='normValue' dir='auto'>%s</div>"
                    "<div class='normLabel'>Cleaned up</div><div class='normValue' dir='auto'>%s</div>"
                    "<div class='normLabel'>Search terms</div><div class='normValue'>%s</div></div>"
                    "<div class='noteSmall'>Green terms are concepts shared by English, Urdu and Roman Urdu, so the same idea matches in every script. "
                    "Other terms are spelling-normalised words.</div>" % (esc(questionText), esc(analysis["normalizedText"]), chipHtml),
                    unsafe_allow_html=True)

        # ---------- evidence with highlighted words
        if topEvidence:
            title = labelSet["evidence"] if decision == "answer" else labelSet["related"]
            st.markdown("<div class='sectionTitle'>%s</div>" % esc(title), unsafe_allow_html=True)
            if decision != "answer":
                st.markdown("<span class='citeChip'>passage %s</span> &nbsp; <span class='openLink'><a href='%s' target='_blank' rel='noopener'>%s</a></span>"
                            % (esc(topEvidence["passageId"]), esc(topEvidence["sourceUrl"]), esc(labelSet["source"])), unsafe_allow_html=True)
            queryTokenSet = set(analysis["tokens"])
            quotedSentences = []
            if decision == "answer":
                leadIn = core.answerLeadIn[responseLanguage]
                quotedBody = result["answerText"][len(leadIn):].strip()
                quotedSentences = [part for part in re.split(r"(?<=[.;؛۔])\s+", quotedBody) if part.strip()]
            tabEnglish, tabUrdu, tabRoman = st.tabs(["English", "اردو", "Roman Urdu"])
            for tabBox, languageCode, passageText in ((tabEnglish, "en", topEvidence["textEn"]), (tabUrdu, "ur", topEvidence["textUr"]),
                                                      (tabRoman, "roman_ur", topEvidence["textRoman"])):
                with tabBox:
                    if not passageText:
                        st.markdown("<div class='noteSmall'>No Roman Urdu rendering for this passage.</div>", unsafe_allow_html=True)
                        continue
                    shownQuotes = quotedSentences if languageCode == responseLanguage else []
                    st.markdown(highlightedBlock(passageText, languageCode == "ur", queryTokenSet, shownQuotes), unsafe_allow_html=True)
                    if languageCode == "roman_ur":
                        st.markdown("<div class='noteSmall'>Roman Urdu is our own unofficial rendering of the official passage.</div>", unsafe_allow_html=True)
            st.markdown("<div class='noteSmall'><mark style='background:#F6E3A3'>Marked words</mark> matched your question (also across scripts). "
                        "<span style='background:#DDEBE1;border-bottom:2px solid #01411C'>Shaded sentences</span> are quoted in the answer.</div>",
                        unsafe_allow_html=True)

        # ---------- score per retrieved passage
        st.markdown("<div class='sectionTitle'>How each passage scored</div>", unsafe_allow_html=True)
        keywordScaled = core.minMaxScale(scores["keywordNormalized"])
        meaningScaled = core.minMaxScale(scores["semanticNormalized"])
        mixWeight = float(engine.params["keywordWeight"])
        barRows = []
        for rank, passageId in enumerate(result["retrievedPassageIds"]):
            index = engine.passageIds.index(passageId)
            mix = mixWeight * keywordScaled[index] + (1 - mixWeight) * meaningScaled[index]
            barRows.append({"passageId": passageId, "topic": engine.passages[index]["topic"], "isTop": rank == 0, "values": [
                (keywordScaled[index], "%.2f (raw %.2f)" % (keywordScaled[index], scores["keywordNormalized"][index])),
                (meaningScaled[index], "%.2f (raw %.2f)" % (meaningScaled[index], scores["semanticNormalized"][index])),
                (mix, "%.2f" % mix)]})
        st.markdown(charts.scoreBarsHtml(barRows, ["Keyword search", "Meaning search", "Weighted mix (keyword weight %.1f)" % mixWeight]), unsafe_allow_html=True)
        st.markdown("<div class='noteSmall'>The top five passages for the chosen method, best first. Both scores are scaled 0 to 1 within this question so they can sit on one chart; "
                    "the raw numbers are in brackets.</div>", unsafe_allow_html=True)

        with st.expander("Raw details (for judges)"):
            st.write({
                "decision": decision, "reason": result["reasonCode"], "whatItMeans": reasonWords.get(result["reasonCode"], ""),
                "normalizedQuery": result["normalizedQuery"], "matchedConcepts": result["matchedConcepts"],
                "retrievalMethod": result["method"], "top5PassageIds": result["retrievedPassageIds"], "latencyMs": result["latencyMs"],
                "thresholds": "tuned on dev data" if usingTunedParams else "defaults (run evaluate.py to tune)",
            })

# ====================================================================== EVALUATION TAB
with tabEvaluation:
    saved = evalData.loadSaved(embedderName)
    if saved is None:
        st.markdown("<div class='resultCard warn'><h2 class='resultTitle'>No evaluation numbers saved yet</h2>"
                    "<div class='answerBody'>Run <code>python evaluate.py</code> once, or press the button below. "
                    "It measures every method on our dev and test questions and saves the numbers for these charts.</div></div>", unsafe_allow_html=True)
        if st.button("Run the evaluation now (about a minute)", key="runEvaluation"):
            import evaluate as evaluateModule
            allPassages, devQueries, testQueries = evaluateModule.loadAllData()
            with st.spinner("Measuring all methods..."):
                evalData.buildAndSave(engine, devQueries, testQueries, embedderName, log=lambda message: None)
            st.rerun()
    else:
        splitChoice = st.radio("Which questions?", ["Held-out test questions", "Dev questions (used for tuning)"], horizontal=True, key="evalSplit")
        splitKey = "test" if splitChoice.startswith("Held-out") else "dev"
        split = saved["splits"][splitKey]
        confusion = split["confusion"]
        answerableTotal = confusion["answeredRight"] + confusion["abstainedWrong"]
        negativeTotal = confusion["answeredWrong"] + confusion["abstainedRight"]
        hybridNumbers = split["retrieval"]["hybrid"]
        st.markdown("<div class='noteSmall'>%d questions: %d answerable, %d that should not be answered. Everything here was measured by our own code, "
                    "nothing is typed in. %s</div>" % (
                        split["questionCount"], split["answerableCount"], split["questionCount"] - split["answerableCount"],
                        "The weights and thresholds were tuned on the dev questions only, so the test numbers are the fair ones."
                        if splitKey == "test" else "These questions were used to tune the system, so these numbers look better than they should."),
                    unsafe_allow_html=True)
        tiles = [
            statusCard("Recall@5 (hybrid)", "ok", "%.1f%%" % (100 * hybridNumbers["recall@5"]), "right passage in the top 5"),
            statusCard("MRR@5 (hybrid)", "ok", "%.3f" % hybridNumbers["mrr@5"], "closer to 1 = right passage nearer the top"),
            statusCard("Answered when it should", "ok", "%.1f%%" % (100 * confusion["answeredRight"] / max(1, answerableTotal)),
                       "%d of %d answerable questions" % (confusion["answeredRight"], answerableTotal)),
            statusCard("Held back when it should", "ok" if confusion["answeredWrong"] == 0 else "warn",
                       "%.1f%%" % (100 * confusion["abstainedRight"] / max(1, negativeTotal)), "%d false answers" % confusion["answeredWrong"]),
        ]
        st.markdown("<div class='statusRow'>%s</div>" % "".join(tiles), unsafe_allow_html=True)

        st.markdown("<div class='sectionTitle'>Retrieval quality by method</div>", unsafe_allow_html=True)
        methodOrder = ["keywordBaseline", "keywordNormalized", "semanticRaw", "semanticNormalized", "hybrid"]
        recallValues = [split["retrieval"][m]["recall@5"] for m in methodOrder]
        mrrValues = [split["retrieval"][m]["mrr@5"] for m in methodOrder]
        st.markdown(charts.groupedBarSvg([methodNames[m] for m in methodOrder], ["Recall@5", "MRR@5"], [recallValues, mrrValues],
                                         [lambda v: "%.0f%%" % (100 * v), lambda v: "%.2f" % v],
                                         "Recall at 5 and MRR at 5 for each retrieval method"), unsafe_allow_html=True)
        st.markdown("<div class='noteSmall'>Plain BM25 reads the words exactly as typed. Normalization fixes spelling, script and word forms first. "
                    "Hybrid mixes keyword and meaning search.</div>", unsafe_allow_html=True)

        st.markdown("<div class='sectionTitle'>Does the same question work in every script?</div>", unsafe_allow_html=True)
        st.markdown(charts.heatmapHtml(split["heatmap"], evalData.languageOrder, languageNames), unsafe_allow_html=True)
        completeRows = [r for r in split["heatmap"] if all(r["cells"][l]["status"] != "none" for l in evalData.languageOrder)]
        allTopOne = sum(all(r["cells"][l]["status"] == "top1" for l in evalData.languageOrder) for r in completeRows)
        allFound = sum(all(r["cells"][l]["status"] in ("top1", "top5") for l in evalData.languageOrder) for r in completeRows)
        st.markdown("<div class='noteSmall'>Hybrid method. Green = right passage ranked first, gold = in the top 5 but not first, red = missed, grey = no question in that script. "
                    "Hover a cell to see the question. %s</div>" % (
                        "Of %d topics asked in all three scripts, %d found the right passage first in every script and %d had it in the top 5 in every script."
                        % (len(completeRows), allTopOne, allFound) if completeRows else "No topic here was asked in all three scripts."), unsafe_allow_html=True)

        st.markdown("<div class='sectionTitle'>Answering and holding back</div>", unsafe_allow_html=True)
        st.markdown(charts.confusionHtml(confusion["answeredRight"], confusion["abstainedWrong"], confusion["answeredWrong"], confusion["abstainedRight"]),
                    unsafe_allow_html=True)
        st.markdown("<div class='noteSmall'>A false answer (answering something the sources cannot support) is worse than a false abstention, "
                    "so the thresholds lean towards holding back.</div>", unsafe_allow_html=True)

        st.markdown("<div class='sectionTitle'>Response time per method</div>", unsafe_allow_html=True)
        latencyValues = saved["latency"]
        slowest = max(v["meanMs"] for v in latencyValues.values()) or 1.0
        st.markdown(charts.barRowsHtml([(methodNames[m], latencyValues[m]["meanMs"] / slowest, "%.1f ms" % latencyValues[m]["meanMs"]) for m in methodOrder]),
                    unsafe_allow_html=True)
        st.markdown("<div class='noteSmall'>Average time to rank the passages, each method run alone on %d sample questions on this machine. "
                    "Hybrid is the slowest because it needs both searches.</div>" % latencyValues["hybrid"]["n"], unsafe_allow_html=True)

        st.markdown("<div class='sectionTitle'>Why we picked this keyword weight</div>", unsafe_allow_html=True)
        sweep = saved["weightSweep"]
        chosen = saved["chosen"]
        modeNames = {"rrf": "Rank fusion", "score": "Score fusion"}
        allRecall = [p["recall@5"] for mode in sweep for p in sweep[mode]]
        allMrr = [p["mrr@5"] for mode in sweep for p in sweep[mode]]

        def axisRange(values):
            # round the axis outwards to a tidy step (0.05, or 0.1 when the values are spread out)
            span = max(values) - min(values)
            step = 0.05 if span <= 0.25 else 0.1
            low = max(0.0, np.floor((min(values) - 0.02) / step) * step)
            high = min(1.0, np.ceil((max(values) + 0.02) / step) * step)
            if high <= low:
                high = low + step
            return float(round(low, 4)), float(round(high, 4)), step

        for metricKey, metricTitle, metricValues, asPercent in (("recall@5", "Recall@5", allRecall, True), ("mrr@5", "MRR@5", allMrr, False)):
            low, high, step = axisRange(metricValues)
            st.markdown(charts.lineChartSvg(
                [(modeNames[mode], [(p["weight"], p[metricKey]) for p in sweep[mode]]) for mode in ("rrf", "score")],
                low, high, step, asPercent, metricTitle, "keyword weight (0 = meaning search only, 1 = keyword search only)",
                markerX=chosen["keywordWeight"], markerText="chosen %.1f (%s)" % (chosen["keywordWeight"], modeNames[chosen["fusionMode"]].lower()),
                description="%s against the hybrid keyword weight on the dev questions" % metricTitle), unsafe_allow_html=True)
        st.markdown("<div class='noteSmall'>Dev questions only. The chosen value is the one with the best dev MRR@5; Recall@5 is nearly flat because the right passage "
                    "is usually somewhere in the top 5, so MRR@5 (how high it ranks) is what separates the settings.</div>", unsafe_allow_html=True)

        st.markdown("<div class='sectionTitle'>Questions the system got wrong</div>", unsafe_allow_html=True)
        failureRows = split["failures"]
        if not failureRows:
            st.markdown("<div class='noteSmall'>No failures in this set.</div>", unsafe_allow_html=True)
        else:
            import pandas as pd
            table = pd.DataFrame([{
                "Problem": row["type"], "ID": row["queryId"], "Language": languageNames.get(row["language"], row["language"]),
                "Question": row["question"], "Right passage": row["expected"], "What the system did": row["systemDid"],
                "Why": reasonWords.get(row["reasonCode"], row["reasonCode"]),
                "Keyword / meaning": "%.2f / %s" % (row["keywordMatch"], "n/a" if row["meaningMatch"] is None else "%.2f" % row["meaningMatch"]),
                "Top 5 found": row["top5"]} for row in failureRows])
            showWide(table)
            st.markdown("<div class='noteSmall'>Most failures are neighbouring passages that say similar things (age rules, fee payment, office steps).</div>",
                        unsafe_allow_html=True)

# ====================================================================== EMBEDDING MAP TAB
with tabMap:
    st.markdown("<div class='noteSmall'>Each dot is one official passage placed by its meaning (embedding). Passages about similar things sit close together. "
                "Your question appears as a star, so you can see which passages it landed near.</div>", unsafe_allow_html=True)
    passageVectors = np.asarray(engine.passageVectors, dtype=float)
    centre = passageVectors.mean(axis=0)
    _, singularValues, components = np.linalg.svd(passageVectors - centre, full_matrices=False)
    axes = components[:2]
    coordinates = (passageVectors - centre) @ axes.T
    keptShare = float((singularValues[:2] ** 2).sum() / (singularValues ** 2).sum())
    queryPoint = None
    topIds = []
    if result is not None:
        queryVector = engine.embedder.encodeQueries([analysis["denseQuery"]])[0]
        projected = (np.asarray(queryVector, dtype=float) - centre) @ axes.T
        queryPoint = (float(projected[0]), float(projected[1]))
        topIds = result["retrievedPassageIds"]
    mapPoints = []
    for index, passage in enumerate(engine.passages):
        role = "other"
        if topIds and passage["passageId"] == topIds[0]:
            role = "first"
        elif passage["passageId"] in topIds:
            role = "top"
        mapPoints.append({"x": float(coordinates[index][0]), "y": float(coordinates[index][1]), "label": passage["passageId"], "role": role,
                          "title": "%s %s: %s" % (passage["passageId"], passage["topic"].replace("_", " "), passage["textEn"][:90])})
    st.markdown(charts.scatterSvg(mapPoints, queryPoint, "Two-dimensional map of the passage embeddings with the question as a star"), unsafe_allow_html=True)
    st.markdown("<div class='sbLegendRow'><span class='sbLegend'>Star = your question</span><span class='sbLegend'>dark green = best match</span>"
                "<span class='sbLegend'>green = next four</span><span class='sbLegend'>grey = other passages</span></div>", unsafe_allow_html=True)
    st.markdown("<div class='noteSmall'>The map squashes %d dimensions into 2 (PCA), keeping %.0f%% of the variation, so distances are only approximate. "
                "Hover a dot to read the passage. %s</div>" % (
                    passageVectors.shape[1], 100 * keptShare,
                    "" if result is not None else "Ask a question to place the star."), unsafe_allow_html=True)

st.markdown(
    "<div class='footerNote'>Information only. Always confirm on the official DGI&amp;P website before you act. "
    "Embedding model: <code>%s</code>; speech model (microphone): <code>faster-whisper %s</code>. Both load on this machine, no outside AI service is called. "
    "The knowledge base is %d excerpts from the organisers' dataset.</div>" % (esc(embedderName), esc(whisperSize), len(engine.passages)),
    unsafe_allow_html=True)
