"""
makeValidationPack.py - builds validation_pack.zip, the evidence folder for the judges.

It reruns the finished system on every labelled question (dev and test), saves one row per question, the
retrieval comparison table, the list of failures and the settings that were used, and zips everything.
Every number is produced by this script from the real run; nothing is typed in by hand.

Run it AFTER evaluate.py (it needs results/tunedParams.json):
    python makeValidationPack.py                      (e5 model, the real results)
    python makeValidationPack.py --embedder hashing   (offline test only, NOT real results)
"""
import argparse
import csv
import json
import os
import shutil
import zipfile

import eSahulatCore as core
import evaluate as ev

packFolder = "validation_pack"
methods = core.EsahulatEngine.retrievalMethods
methodNames = {"keywordBaseline": "BM25 (plain)", "keywordNormalized": "BM25 + normalization",
               "semanticRaw": "Semantic (plain)", "semanticNormalized": "Semantic + normalization", "hybrid": "Hybrid"}


def writeCsv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8-sig") as outFile:      # utf-8-sig so Excel shows Urdu correctly
        writer = csv.writer(outFile)
        writer.writerow(header)
        writer.writerows(rows)


def perQueryRows(engine, queries):
    rows = []
    for query in queries:
        result = engine.answerQuery(query["text"], responseLanguage="en", method="hybrid")
        answered = result["decision"] == "answer"
        citedId = result["evidence"][0]["passageId"] if (answered and result["evidence"]) else ""
        gold = query["relevantPassageId"] or ""
        if query["answerable"]:
            outcome = ("correct answer" if citedId == gold else "wrong passage cited") if answered else "false abstention"
        else:
            outcome = "false answer" if answered else "correctly held back"
        rows.append([query["queryId"], query["language"], query["topic"], query["answerable"], query["text"], gold,
                     result["decision"], result["reasonCode"], citedId, outcome, result["coverage"], result["semanticScore"],
                     " ".join(result["retrievedPassageIds"]), result["latencyMs"], result["answerText"] or result["message"]])
    return rows


perQueryHeader = ["queryId", "language", "topic", "answerable", "question", "goldPassage", "decision", "reasonCode", "citedPassage",
                  "outcome", "keywordMatch", "meaningMatch", "top5Passages", "latencyMs", "systemText"]


def retrievalRows(engine, queries, splitName):
    summary, perMethod, answerable = ev.evaluateRetrieval(engine, queries, methods)
    rows = []
    for method in methods:
        overall = summary[method]["overall"]
        rows.append([splitName, "all", methodNames[method], overall["n"], round(overall["recall@1"], 4), round(overall["recall@5"], 4), round(overall["mrr@5"], 4)])
        for language in ev.languages:
            part = summary[method]["byLanguage"][language]
            if part:
                rows.append([splitName, language, methodNames[method], part["n"], round(part["recall@1"], 4), round(part["recall@5"], 4), round(part["mrr@5"], 4)])
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--embedder", default="e5", choices=["e5", "hashing"])
    parser.add_argument("--model", default=core.defaultEmbeddingModel)
    arguments = parser.parse_args()

    passages, devQueries, testQueries = ev.loadAllData()
    embedder = core.makeEmbedder(arguments.embedder, arguments.model)
    tuned = core.loadTunedParams("results/tunedParams.json", embedder.name)
    if tuned is None:
        raise SystemExit("results/tunedParams.json has no settings for %s. Run evaluate.py first." % embedder.name)
    engine = core.EsahulatEngine(passages, embedder, tuned)
    print("Engine ready:", embedder.name, tuned)

    if os.path.exists(packFolder):
        shutil.rmtree(packFolder)
    os.makedirs(packFolder)

    testRows, devRows = perQueryRows(engine, testQueries), perQueryRows(engine, devQueries)
    writeCsv(os.path.join(packFolder, "per_question_results_test.csv"), perQueryHeader, testRows)
    writeCsv(os.path.join(packFolder, "per_question_results_dev.csv"), perQueryHeader, devRows)
    print("Per-question results written:", len(testRows), "test rows,", len(devRows), "dev rows")

    comparison = retrievalRows(engine, testQueries, "test") + retrievalRows(engine, devQueries, "dev")
    writeCsv(os.path.join(packFolder, "retrieval_comparison.csv"),
             ["split", "language", "method", "answerableQuestions", "recall@1", "recall@5", "mrr@5"], comparison)

    failures = [row for row in testRows + devRows if row[9] in ("wrong passage cited", "false abstention", "false answer")]
    writeCsv(os.path.join(packFolder, "failures.csv"), perQueryHeader, failures)
    print("Failures listed:", len(failures))

    with open(os.path.join(packFolder, "settings_used.json"), "w", encoding="utf-8") as settingsFile:
        json.dump({"embedder": embedder.name, "tunedOnDevOnly": tuned, "retrievalMethodsCompared": methods,
                   "devQuestions": len(devQueries), "testQuestions": len(testQueries), "passages": len(passages)}, settingsFile, indent=2)

    # copy the evidence files that already exist
    for source in ["results/evaluationReport.md", "data/passages.json", "data/queries.json", "data/devNegatives.json"]:
        if os.path.exists(source):
            shutil.copy(source, os.path.join(packFolder, os.path.basename(source)))
    safeName = embedder.name.replace("/", "_")
    for source in ["results/evaluationResults_%s.json" % safeName, "results/evalTab_%s.json" % safeName]:
        if os.path.exists(source):
            shutil.copy(source, os.path.join(packFolder, os.path.basename(source)))

    with open(os.path.join(packFolder, "README.txt"), "w", encoding="utf-8") as readme:
        readme.write(
            "Validation pack - Multilingual E-Sahulat AI\n\n"
            "per_question_results_test.csv / _dev.csv : one row per labelled question - the system's decision, the cited passage,\n"
            "                                           the scores, the top 5 passages and whether the outcome was right.\n"
            "retrieval_comparison.csv                 : Recall@1, Recall@5 and MRR@5 for the five retrieval methods, overall and by language.\n"
            "failures.csv                             : only the rows where the system was wrong (wrong passage, false abstention, false answer).\n"
            "settings_used.json                       : embedding model and the thresholds and fusion weight tuned on dev data only.\n"
            "evaluationReport.md                      : the full written report produced by evaluate.py.\n"
            "passages.json, queries.json, devNegatives.json : the knowledge base, the organisers' labelled questions (train_dev / test split)\n"
            "                                           and the team-written negative questions used only for tuning.\n\n"
            "How to reproduce: python buildData.py && python evaluate.py && python makeValidationPack.py\n"
            "The test questions were never used for tuning. Embedding model: %s\n" % embedder.name)

    zipName = "validation_pack.zip"
    with zipfile.ZipFile(zipName, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(os.listdir(packFolder)):
            archive.write(os.path.join(packFolder, name), os.path.join(packFolder, name))
    print("Done:", zipName)


if __name__ == "__main__":
    main()
