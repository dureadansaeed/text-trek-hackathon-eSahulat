# Multilingual E-Sahulat AI (passport domain)

Evidence-grounded retrieval assistant for Urdu script, Roman Urdu, English and code-mixed questions.
It answers **only by quoting a cited official passage**, and abstains / asks for clarification when the evidence is weak.
No API calls: the only model is a multilingual sentence-embedding model loaded locally.

## Install and run
```bash
pip install -r requirements.txt
python buildData.py                 # dataset file -> data/passages.json, queries.json, devNegatives.json
python evaluate.py                  # downloads intfloat/multilingual-e5-small once, tunes on dev, writes results/
streamlit run app.py                # the demo interface
```
Offline fallback (weaker semantic part, for debugging only): `python evaluate.py --embedder hashing` and
`ESAHULAT_EMBEDDER=hashing streamlit run app.py`.

## The interface (app.py)
Three tabs. **Answer**: answer card, confidence meter (evidence strength vs the answer line), status cards, normalization view, highlighted evidence, score bars per passage.
**Evaluation**: grouped bar chart (Recall@5, MRR@5 per method), cross-script heatmap, answered/abstained matrix, latency per method, keyword-weight sweep, table of failures.
**Embedding map**: PCA of the passage embeddings with the question as a star. The sidebar keeps the question history.
The Evaluation tab reads `results/evalTab_<model>.json`, which `evaluate.py` writes (code in `evalData.py`); charts are drawn by `charts.py` without a plotting library.

## Microphone (optional)
The app has a "Speak your question" box. Audio is recorded in the browser, sent only to our own Streamlit process, and transcribed locally by
`faster-whisper` (open-source Whisper, default size `small`, change with `ESAHULAT_WHISPER=base`). No hosted speech or AI service is used.
Whisper writes Urdu speech in Urdu script and English in English (not Roman Urdu); the text then goes through the normal pipeline.
The speech model is an extra open-source model that is not part of the evaluation, and we have not measured its accuracy.

## Architecture
```
question --> normalise (Unicode/Urdu letters, diacritics, phrase rules)
         --> safety guards (prompt injection, personal status/guarantees, appointments, outdated-fee, unsafe, ambiguity)
         --> retrieval: keyword BM25 over concept tokens  +  e5 semantic search  --> weighted reciprocal-rank fusion (hybrid)
         --> confidence check (keyword coverage + semantic score, thresholds tuned on dev only)
         --> answer = sentences quoted from the top passage + passage id + document id + source URL
             or  abstain / clarify message in the selected language
```
Technical contributions (all in `eSahulatCore.py`):
1. **Cross-script concept thesaurus** - the same idea in English, Roman Urdu and Urdu script maps to one token (`c_child`, `c_renew`...), so Urdu questions match English evidence exactly.
2. **Phonetic skeleton** for Roman Urdu spelling variation (`pasport/passport/paasport -> psprt`, `documnts -> dkmnt`).
3. **Hybrid retrieval** with a fusion weight tuned on dev data, compared against keyword-only and semantic-only baselines.
4. **Abstention** = rule guards + two-feature confidence threshold (keyword coverage, semantic score).

## Models, data, preprocessing (disclosure)
- Embedding model: `intfloat/multilingual-e5-small` (open source, loaded locally via sentence-transformers). Change `defaultEmbeddingModel` in `eSahulatCore.py` for a bigger one (e.g. `intfloat/multilingual-e5-base`).
- Keyword search: BM25 implemented from scratch (no library).
- Dataset: `data/hackathonDataset.txt` provided by the organisers - 30 official excerpts (EN + UR) from DGI&P pages, 150 labelled queries (90 `train_dev`, 60 `test`).
  Provenance per passage (`passageId`, `docId`, `sourceUrl`) is in `data/passages.json`. Source pages: dgip.gov.pk (types, ordinary-passport, process, faq, online-passport).
  The dataset notes say source freshness should be re-checked before real deployment.
- Team-written extra negatives for tuning: `data/devNegatives.json` (26 queries, written by us, not copied from the test split).
- Test queries are **never used for tuning**. Thresholds and the fusion weight are tuned on `train_dev` + team-written negatives only.

## Evaluation (run `python evaluate.py`)
Produces `results/evaluationReport.md` and `results/evaluationResults.json` with: Recall@5, MRR@5 for keyword baseline vs normalised keyword vs semantic vs hybrid,
per-language breakdown, cross-script consistency, abstention performance, citation correctness, latency, and an error list.

## Honest limitations
- The knowledge base is only the 30 excerpts in the dataset, so retrieval is easier than over full websites. Add more passages (same JSON format) to make the evaluation harder and more realistic.
- Only one passage is cited per answer; a question needing two passages gets one.
- Safety-guard rules were written from the problem statement's failure categories after seeing the structure of the test file, so test-split abstention numbers are optimistic. Retrieval numbers do not depend on those rules.
- No fee amounts exist in the knowledge base, so every fee question correctly asks for clarification or abstains.
- Roman Urdu answers use `textRoman`, our own (unofficial) Roman Urdu rendering of each Urdu/English excerpt written by the team (see `romanUrduRenderings` in `buildData.py`); the official passages exist only in English and Urdu script. Retrieval does not use `textRoman`.
- Citation support is guaranteed by construction (answers are quotes); "citation correctness" (is the cited passage the gold one) is the meaningful measure.

## Event deliverables
- `running_nb.ipynb` - Colab notebook that runs everything in order (install, data, evaluation, validation pack, app link, optional GitHub push).
- `makeValidationPack.py` - builds `validation_pack.zip` (per-question results, retrieval comparison, failures, settings used). Run after `evaluate.py`.
- Technical report, retrieval comparison table and slides are delivered separately.
