"""
eSahulatCore.py
The engine behind Multilingual E-Sahulat AI.

What it does, in plain words:
  1. cleans a question (Urdu script, Roman Urdu, English or a mix)
  2. finds the best passages in our small official-document knowledge base
       - keyword search (BM25)         -> good when the same words appear
       - semantic search (embeddings)  -> good when the wording is different
       - hybrid (both combined)        -> usually the best of both
  3. decides: answer / ask for clarification / abstain
  4. builds an answer ONLY by quoting the passage it found, with its source link

Nothing here calls an online API. The only model is a sentence-embedding model that is
loaded locally with sentence-transformers.
"""
import json
import math
import re
import time
import unicodedata
import zlib
from collections import Counter, defaultdict

import numpy as np

defaultEmbeddingModel = "intfloat/multilingual-e5-small"
rrfConstant = 60                       # standard value for reciprocal rank fusion
defaultParams = {"semThreshold": 0.0, "coverageThreshold": 0.34, "keywordWeight": 0.5, "fusionMode": "rrf"}

# ------------------------------------------------------------------------------------
# 1. TEXT NORMALISATION
# ------------------------------------------------------------------------------------

# Different keyboards type the "same" Urdu letter with different Unicode characters.
# We map them all to one version so that string matching works.
urduCharFixes = {
    "ي": "ی",   # Arabic yeh -> Urdu yeh
    "ى": "ی",   # alef maksura -> Urdu yeh
    "ې": "ی",
    "ك": "ک",   # Arabic kaf -> Urdu kaf
    "ه": "ہ",   # Arabic heh -> Urdu heh goal
    "ۃ": "ہ",
    "ة": "ہ",
    "أ": "ا",   # alef with hamza -> plain alef
    "إ": "ا",
    "ٱ": "ا",
}
for position, digit in enumerate("٠١٢٣٤٥٦٧٨٩"):          # Arabic-Indic digits
    urduCharFixes[digit] = str(position)
for position, digit in enumerate("۰۱۲۳۴۵۶۷۸۹"):          # Urdu / Persian digits
    urduCharFixes[digit] = str(position)
urduCharTable = str.maketrans(urduCharFixes)

# zabar/zer/pesh marks, tatweel and invisible joiners add nothing to the meaning
invisibleMarks = re.compile("[ً-ٰٟـ​-‏‪-‮﻿]")
digitLetterBoundary = re.compile(r"(?<=\d)(?=[^\W\d_])|(?<=[^\W\d_])(?=\d)")


def basicNormalize(text):
    text = unicodedata.normalize("NFKC", str(text))
    text = text.translate(urduCharTable)
    text = invisibleMarks.sub("", text)
    text = text.lower()
    text = digitLetterBoundary.sub(" ", text)          # "10saal" -> "10 saal"
    text = re.sub(r"[^\w\s]|_", " ", text)             # punctuation (incl. ؟ ۔ ،) -> space
    return re.sub(r"\s+", " ", text).strip()


# Short domain phrases that are written in many ways. We rewrite them to one token first.
phraseRules = [
    (r"\bfast\s*tr[a-z]*k\w*\b", "fasttrack"),
    (r"\bfinger\s*prints?\b", "fingerprints"),
    (r"\be passport\b", "epassport"),
    (r"\bdgi p\b", "dgip"),
    (r"\bid card\b", "cnic"),
    (r"\bworking days?\b", "working day"),
]
for urduPhrase, replacement in [
    ("این او سی", "noc"), ("ایم آر پی", "mrp"), ("ای پاسپورٹ", "epassport"),
    ("آن لائن", "online"), ("آنلائن", "online"), ("فاسٹ ٹریک", "fasttrack"),
    ("فنگر پرنٹس", "fingerprints"), ("فنگر پرنٹ", "fingerprints"),
    ("ڈیتھ سرٹیفکیٹ", "death certificate"), ("پولیس رپورٹ", "police report"),
    ("کاروباری دن", "working day"), ("شناختی کارڈ", "cnic"), ("آر پی او", "rpo"),
]:
    phraseRules.append((r"(?<!\w)" + re.escape(basicNormalize(urduPhrase)) + r"(?!\w)", replacement))
phraseRules = [(re.compile(pattern), replacement) for pattern, replacement in phraseRules]


def normalizeForSearch(text):
    cleaned = basicNormalize(text)
    for pattern, replacement in phraseRules:
        cleaned = pattern.sub(replacement, cleaned)
    return cleaned


def isLatinWord(word):
    return re.fullmatch(r"[a-z]+", word) is not None


def phoneticSkeleton(word):
    """
    Roman Urdu has no fixed spelling: pasport / passport / paasport, documnts / documents.
    We squash a word into a rough "sound skeleton": merge look-alike letters, drop repeated
    letters and drop vowels (except the first letter). Spelling variants then end up identical.
        passport -> psprt     pasport -> psprt     paasport -> psprt
        documents -> dkmnt    documnts -> dkmnt
    """
    if not isLatinWord(word):
        return word
    if len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
        word = word[:-1]                                   # documents -> document
    word = word.replace("ph", "f").replace("q", "k").replace("c", "k")
    word = word.replace("z", "s").replace("w", "v")
    word = re.sub(r"(.)\1+", r"\1", word)
    return word[0] + re.sub(r"[aeiouy]", "", word[1:])


# ------------------------------------------------------------------------------------
# 2. SMALL LEXICONS (stop-words and a cross-script concept thesaurus)
# ------------------------------------------------------------------------------------

englishStops = """a an the is are was were be been do does did i my me we you your to of for in on at and or
can could what which who whom how when where should must it its if any there by with as from that this will
would have has had am so than then also much many about get""".split()
romanUrduStops = """hai hain hy hy ho hoti hota hote hon hoga hogi ka ki ke ko se mein main me par pe per ya aur
kya kia kaun kon kaunsa konsa konsi kaunsi kese kaise kesay kaisay kahan kitna kitni kitne kitnay tou to bhi hi ne
ap aap mera meri mere mujhe mujhay hum kar karna karne karo karoon sakta sakti sakte saktay skta skti chahiye
chahye chahiyen zaroori zarori lagta lagtay jaye jayen jati jata jatay walay wala wali wale liye liay lye keh
yeh ye wo woh is us un agar to phir tak sath saath kuch koi ab abhi k ky kyun kyunke karwana karwanay karwa
karwaana karta karti kartay karein karen karun banta banti bante banay hona honay hone hun hoon lena lenay lana
lanay dena denay jana jane aana aanay milta milti milte milay chahyen chahiyen chahyay jahan wahan yahan jab tab
jese jaise hasil han nahi nahin na mat bohat bahut karte waqt hotay hotey leta leti letay lete rahe rahi raha hua
hui hue gaya gayi""".split()
urduStops = """کا کی کے کو سے میں پر اور یا کیا کون سی سا ہے ہیں ہو ہوں ہوتا ہوتی ہوتے تو بھی ہی نے کہ جو اس ان وہ یہ لیے
کر سکتا سکتی سکتے کرنا کرنے کریں چاہیے چاہئیں چاہئے مجھے میرا میری میرے کتنے کتنی کتنا کس کسی کوئی گا گی گے
ہوگا ہوگی لازمی درکار ہیں تھا تھی تھے""".split()
stopWords = set(basicNormalize(word) for word in englishStops + romanUrduStops + urduStops)

# One concept = the same idea written in English, Roman Urdu and Urdu script.
# Words from any script that belong together are mapped to ONE token (c_<concept>),
# so an Urdu question can match English evidence and the other way round.
# Built from the train/dev questions and domain knowledge. Extend it as you read more documents.
conceptGroups = {
    "passport": ("passport", "passport passports pasport paasport pasaport passprt پاسپورٹ پاسپورٹس".split()),
    "document": ("document", "document documents documnts dastavez dastawez dastaveez dastavezat dastawezat "
                 "dastaveezat دستاویز دستاویزات کاغذات کاغذ paper papers kaghaz kagzat".split()),
    "child": ("child minor", "child children minor minors kid kids bacha bachay bachey bache bachon bachy bachi "
              "بچہ بچے بچی بچوں نابالغ".split()),
    "parent": ("parent mother father guardian", "parent parents walid walidain walideen walda walidah والدین والد "
               "والدہ ماں باپ mother father maa baap guardian sarparast سرپرست".split()),
    "lost": ("lost", "lost gum gumshuda گم گمشدہ".split()),
    "police": ("police", "police pulis پولیس".split()),
    "report": ("report", "report reports رپورٹ".split()),
    "fee": ("fee cost charges", "fee fees cost price charge charges qeemat kimat kharcha kharch فیس قیمت خرچہ خرچ".split()),
    "renew": ("renew renewal", "renew renewal renewed renu renue renewl tajdeed tajdid تجدید".split()),
    "online": ("online", "online onlin onlne internet portal پورٹل web ویب".split()),
    "overseas": ("overseas abroad", "overseas abroad bahir bahar bairon bairoon pardes بیرون بیرونی مقیم پردیس".split()),
    "dual": ("dual nationality foreign", "dual dohri dohra دوہری nationality national nationals shehriyat shahriyat "
             "شہریت foreign ملکی".split()),
    "validity": ("validity", "validity valid miaad meaad miyad میعاد muddat مدت".split()),
    "year": ("years", "year years yr yrs saal sal سال baras برس".split()),
    "day": ("days", "day days din dino دن دنوں".split()),
    "working": ("working", "working kaarobari karobari کاروباری".split()),
    "processing": ("processing", "processing process processed kaarrawai karrawai کارروائی عمل".split()),
    "normal": ("normal", "normal regular نارمل".split()),
    "urgent": ("urgent", "urgent urgnt ارجنٹ fori فوری jaldi".split()),
    "fasttrack": ("fast track", ["fasttrack"]),
    "fingerprint": ("fingerprints biometrics", "fingerprints fingerprint biometric biometrics bayometrics بایومیٹرکس "
                    "فنگر انگلیوں ungli".split()),
    "interview": ("interview", "interview interviews انٹرویو".split()),
    "verification": ("verification", "verification verify verified tasdeeq tasdiq تصدیق".split()),
    "refund": ("refund", "refund refundable refunded wapis wapsi واپس واپسی ناقابل".split()),
    "transfer": ("transfer", "transfer transferable muntaqil منتقل منتقلی".split()),
    "payment": ("pay payment", "pay paid payment ada adaigi ادا ادائیگی credit debit کریڈٹ ڈیبٹ".split()),
    "card": ("card", "card کارڈ".split()),
    "page": ("pages", "page pages safha safhat safhe صفحہ صفحات".split()),
    "end": ("expired exhausted finished", "expire expired expiry expires expiration exhausted khatam khtm ختم".split()),
    "name": ("name", "name names naam nam نام".split()),
    "change": ("change modify", "change changes modify revise badalna badal tabdeel tabdili تبدیل تبدیلی ترمیم".split()),
    "cnic": ("CNIC identity card", "cnic nicop nic id shanakhti شناختی identity".split()),
    "adult": ("adult 18", "adult adults baligh بالغ eighteen 18".split()),
    "older": ("above older", "above older baray bare barey بڑے zyada زیادہ".split()),
    "younger": ("below younger under", "below under younger chotay chotey chote chhotay chhote چھوٹے کم".split()),
    "government": ("government", "government govt sarkari سرکاری".split()),
    "employee": ("employee", "employee employees employe mulazim ملازم ملازمین mulazmeen".split()),
    "noc": ("NOC", "noc nocs".split()),
    "office": ("office", "office offices daftar dafter دفتر rpo rpos".split()),
    "city": ("city", "city cities shehar sheher شہر شہروں".split()),
    "courier": ("courier delivery", "courier couriers delivery deliver delivered tarseel ترسیل کوریئر".split()),
    "mrp": ("MRP machine readable passport", "mrp مشین ریڈایبل machine readable".split()),
    "epassport": ("e-passport", ["epassport"]),
    "types": ("types", "type types qism aqsam قسم اقسام kinds kind".split()),
    "ordinary": ("ordinary", "ordinary aam عام".split()),
    "ten": ("10", "10 ten das dus دس".split()),
    "five": ("5", "5 five panch paanch پانچ".split()),
    "fifteen": ("15", "15 fifteen pandrah pandra پندرہ".split()),
    "death": ("death deceased", "death deceased died dead wafat wafaat وفات فوت marhoom مرحوم maut موت".split()),
    "certificate": ("certificate", "certificate certificates sanad سرٹیفکیٹ".split()),
    "divorce": ("divorced separated custody", "divorce divorced separated separation custody talaq طلاق علیحدگی "
                "alehdagi alahida tahweel تحویل".split()),
    "court": ("court", "court courts adalat عدالت".split()),
    "apply": ("apply application", "apply application applicant applicants applying darkhwast darkhast درخواست گزار".split()),
    "address": ("address", "address pata پتہ پتے".split()),
    "permission": ("permission consent", "permission consent ijazat اجازت".split()),
    "separate": ("separate", "separate alag الگ".split()),
    "add": ("add endorsement", "add added endorsement endorsements darj درج".split()),
    "firstLast": ("first last name", "first last پہلا آخری akhri aakhri".split()),
    "photo": ("photograph", "photo photograph picture tasveer تصویر".split()),
    "copy": ("photocopy", "photocopy copy copies فوٹو کاپی نقل".split()),
    "token": ("token QR", "token qr ٹوکن".split()),
    "original": ("original", "original asal اصل".split()),
    "citizen": ("citizen", "citizen citizens shehri شہری شہریوں".split()),
    "travel": ("travel", "travel safar سفر".split()),
    "available": ("available", "available availability dastiyab دستیاب maujood موجود".split()),
    "restriction": ("restriction", "restriction pabandi پابندی".split()),
    "before": ("before", "before pehle pehlay pahlay پہلے".split()),
    "inland": ("inland", "inland andar اندر".split()),
}

exactFormToConcept = {}
skeletonToConcept = {}


def buildConceptLookups():
    skeletonOwners = defaultdict(set)
    for conceptId, (gloss, forms) in conceptGroups.items():
        for form in forms:
            word = basicNormalize(form)
            if not word or " " in word:
                continue
            if word.isdigit():
                word = str(int(word))
            exactFormToConcept.setdefault(word, conceptId)
            # spelling-variant matching only for longer Latin words (short ones collide too often)
            if isLatinWord(word) and len(word) >= 5:
                skeleton = phoneticSkeleton(word)
                if len(skeleton) >= 3:
                    skeletonOwners[skeleton].add(conceptId)
                    skeletonToConcept.setdefault(skeleton, conceptId)
    # a skeleton shared by two different concepts is ambiguous, so we do not use it for spelling-variant matching
    for skeleton, owners in skeletonOwners.items():
        if len(owners) > 1:
            del skeletonToConcept[skeleton]


buildConceptLookups()


def lookUpConcept(word):
    conceptId = exactFormToConcept.get(word)
    if conceptId is None and isLatinWord(word) and len(word) >= 5:
        conceptId = skeletonToConcept.get(phoneticSkeleton(word))
    return conceptId


def toSearchTokens(normalizedText):
    """words -> (tokens for keyword search, list of concept ids that were recognised)"""
    tokens, concepts = [], []
    for word in normalizedText.split():
        if word.isdigit():
            word = str(int(word))                           # "05" and "5" are the same number
        if word in stopWords:
            continue
        conceptId = lookUpConcept(word)
        if conceptId:
            tokens.append("c_" + conceptId)
            concepts.append(conceptId)
        elif isLatinWord(word):
            tokens.append(phoneticSkeleton(word))
        else:
            tokens.append(word)
    return tokens, concepts


def rawTokens(text):
    # the plain baseline: lowercase words, nothing clever
    return re.findall(r"\w+", str(text).lower())


# ------------------------------------------------------------------------------------
# 3. RETRIEVERS
# ------------------------------------------------------------------------------------

class BM25Index:
    """Classic BM25 keyword scoring, written by hand so it is easy to explain."""

    def __init__(self, tokenizedDocs, k1=1.5, b=0.75):
        self.k1, self.b = k1, b
        self.docLengths = [len(doc) for doc in tokenizedDocs]
        self.avgLength = sum(self.docLengths) / max(1, len(tokenizedDocs))
        self.termCounts = [Counter(doc) for doc in tokenizedDocs]
        docFrequency = Counter()
        for counts in self.termCounts:
            docFrequency.update(counts.keys())
        docTotal = len(tokenizedDocs)
        # rare words get a big weight, words in every passage get a tiny one
        self.idf = {term: math.log(1 + (docTotal - freq + 0.5) / (freq + 0.5)) for term, freq in docFrequency.items()}

    def score(self, queryTokens):
        scores = np.zeros(len(self.termCounts))
        for term in set(queryTokens):
            if term not in self.idf:
                continue
            for docIndex, counts in enumerate(self.termCounts):
                termCount = counts.get(term, 0)
                if termCount == 0:
                    continue
                lengthPart = 1 - self.b + self.b * self.docLengths[docIndex] / self.avgLength
                scores[docIndex] += self.idf[term] * termCount * (self.k1 + 1) / (termCount + self.k1 * lengthPart)
        return scores


def cleanForEmbedding(text):
    # light touch: fix Unicode variants but keep the sentence natural for the neural model
    text = unicodedata.normalize("NFKC", str(text)).translate(urduCharTable)
    return re.sub(r"\s+", " ", invisibleMarks.sub("", text)).strip()


class SentenceTransformerEmbedder:
    """Local multilingual embedding model (no API). e5 models want 'query: ' / 'passage: ' prefixes."""

    def __init__(self, modelName=defaultEmbeddingModel):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(modelName)
        self.name = modelName
        self.usesE5Prefix = "e5" in modelName.lower()

    def encodePassages(self, texts):
        prefix = "passage: " if self.usesE5Prefix else ""
        return np.asarray(self.model.encode([prefix + t for t in texts], normalize_embeddings=True,
                                            show_progress_bar=False))

    def encodeQueries(self, texts):
        prefix = "query: " if self.usesE5Prefix else ""
        return np.asarray(self.model.encode([prefix + t for t in texts], normalize_embeddings=True,
                                            show_progress_bar=False))


class CharNgramEmbedder:
    """
    Offline fallback / extra baseline: hashes character n-grams into a vector.
    No download needed and it tolerates spelling mistakes, but it cannot match Urdu script
    to English the way a real multilingual model can.
    """

    def __init__(self, dimension=4096, ngramSizes=(3, 4, 5)):
        self.dimension, self.ngramSizes = dimension, ngramSizes
        self.name = "charNgramHashing"

    def encodePassages(self, texts):
        matrix = np.zeros((len(texts), self.dimension), dtype=np.float32)
        for row, text in enumerate(texts):
            padded = " " + normalizeForSearch(text) + " "
            for size in self.ngramSizes:
                for start in range(len(padded) - size + 1):
                    column = zlib.crc32(padded[start:start + size].encode("utf-8")) % self.dimension
                    matrix[row, column] += 1
        matrix = np.log1p(matrix)
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1
        return matrix / norms

    encodeQueries = encodePassages


def makeEmbedder(kind="e5", modelName=defaultEmbeddingModel):
    if kind == "hashing":
        return CharNgramEmbedder()
    try:
        return SentenceTransformerEmbedder(modelName)
    except Exception as error:                              # no internet / package missing
        print("WARNING: could not load", modelName, "->", repr(error))
        print("WARNING: falling back to the offline charNgramHashing embedder. Results are NOT e5 results.")
        return CharNgramEmbedder()


def minMaxScale(values):
    low, high = float(np.min(values)), float(np.max(values))
    if high - low < 1e-9:
        return np.zeros(len(values))
    return (np.asarray(values) - low) / (high - low)


def rankByScore(scores, dropZeros=False):
    order = sorted(range(len(scores)), key=lambda index: (-scores[index], index))
    if dropZeros:
        order = [index for index in order if scores[index] > 0]
    return order


# ------------------------------------------------------------------------------------
# 4. SAFETY GUARDS (rules that run before retrieval)
# ------------------------------------------------------------------------------------
# Every rule is a list of word-groups. The rule fires when EVERY group has at least one
# phrase in the question. A phrase ending with * matches any ending (deliver* -> delivered).
# Rules were written from the problem statement's failure categories (injection, personal status,
# guarantees, ambiguity, out-of-domain, outdated evidence) - see the README for the honest caveat.

def compilePhrase(phrase):
    phrase = basicNormalize(phrase.replace("*", "")) + ("*" if phrase.endswith("*") else "")
    body = re.escape(phrase.rstrip("*"))
    return re.compile(r"(?<!\w)" + body + (r"\w*" if phrase.endswith("*") else r"(?!\w)"))


def compileRule(groups):
    return [[compilePhrase(phrase) for phrase in group] for group in groups]


possessiveWords = ["my", "mera", "meri", "mere", "میرا", "میری", "میرے"]
guardRules = [
    ("injection", [["ignore", "forget", "disregard", "override", "نظر انداز", "بھول جاو", "bhool jao", "nazar andaz"],
                   ["rules", "rule", "instructions", "instruction", "prompt", "guidelines", "qawaid", "قواعد",
                    "ہدایات", "hidayat*", "pichli", "previous"]]),
    ("injection", [["invent", "make up", "fabricate", "pretend", "jhoota", "jhooti", "جھوٹا", "جھوٹی"]]),
    ("injection", [["bana do", "bana dena", "banao", "بنا دو", "بنا دیں", "بنا دیجیے"],
                   ["jawab", "answer", "جواب", "fee", "fees", "فیس", "maloomat", "معلومات"]]),
    ("injection", [["without", "no", "na", "mat", "bina", "بغیر", "مت"],
                   ["source", "sources", "cite", "citation*", "reference*", "hawala", "hawale", "حوالہ", "حوالے", "ماخذ"]]),
    ("injection", [["system prompt", "jailbreak", "developer mode"]]),
    ("unsafe", [["bypass", "circumvent", "fake", "forge", "forged", "fraud", "jaali", "jali", "جعلی", "جعل",
                 "illegal", "غیر قانونی"],
                ["passport", "verification", "police", "cnic", "documents", "document", "پاسپورٹ", "تصدیق"]]),
    ("timeSensitive", [["still", "currently", "today", "latest", "right now", "abhi", "aaj", "ab bhi", "اب بھی",
                        "آج", "ابھی", "تازہ", "موجودہ", "current", "up to date", "2023", "2024", "2025", "2026"],
                       ["fee", "fees", "cost", "price", "charges", "processing", "validity", "valid", "current",
                        "فیس", "قیمت", "معلومات", "information", "info", "times", "lagu*", "laagu*", "لاگو",
                        "applicable"]]),
    ("noGuarantee", [["guarantee", "guaranteed", "guarantees", "promise", "definitely", "surely", "pakka", "pakki",
                      "yaqeeni", "yaqini", "yaqeen", "ضمانت", "یقینی", "یقین", "لازما"]]),
    ("personalStatus", [possessiveWords,
                        ["status", "tracking", "track", "اسٹیٹس", "سٹیٹس", "حیثیت", "ٹریکنگ", "approved", "approve",
                         "approval", "منظور", "منظوری", "decision", "result"]]),
    ("personalTiming", [["kab", "kb", "when", "کب"],
                        ["pohanch*", "pahunch*", "pohnch*", "ayega", "aayega", "aaye", "milega", "milay", "miley",
                         "ready", "deliver*", "arriv*", "reach*", "receive*", "پہنچ*", "ملے", "تیار", "آئے"],
                        possessiveWords]),
    ("unsupportedAction", [["appointment", "apointment", "booking", "book", "schedule", "اپائنٹمنٹ", "اپوائنٹمنٹ", "slot"]]),
    ("conflict", [["another page", "other page", "another source", "other source", "another document",
                   "another website", "something else", "conflict*", "contradict*", "discrepan*", "dusra page",
                   "dusre page", "aik aur page", "ایک اور صفحہ", "دوسرے صفحے", "دوسرا صفحہ"]]),
]
guardRules = [(name, compileRule(groups)) for name, groups in guardRules]
guardsThatShowRelatedEvidence = {"personalStatus", "personalTiming"}


def firstGuardThatFires(normalizedQuery):
    for name, groups in guardRules:
        if all(any(pattern.search(normalizedQuery) for pattern in group) for group in groups):
            return name
    return None


# ------------------------------------------------------------------------------------
# 5. MESSAGES (answer / abstain / clarify text in the three response languages)
# ------------------------------------------------------------------------------------
responseMessages = {
    "noEvidence": {
        "en": "I could not find enough verified evidence in the passport knowledge base to answer this. Please check the official DGI&P website (dgip.gov.pk) or contact your Regional Passport Office.",
        "ur": "پاسپورٹ کے علمی ذخیرے میں اس سوال کا جواب دینے کے لیے مصدقہ ثبوت نہیں ملا۔ براہِ کرم سرکاری ویب سائٹ dgip.gov.pk دیکھیں یا اپنے علاقائی پاسپورٹ دفتر سے رابطہ کریں۔",
        "roman_ur": "Passport knowledge base mein is sawal ka jawab dene ke liye kaafi mustanad saboot nahi mila. Meherbani karke official website dgip.gov.pk dekhein ya apne Regional Passport Office se rabta karein."},
    "outOfDomain": {
        "en": "This question is outside the passport-services knowledge base, so I cannot answer it.",
        "ur": "یہ سوال پاسپورٹ خدمات کے علمی ذخیرے سے باہر ہے، اس لیے میں اس کا جواب نہیں دے سکتا۔",
        "roman_ur": "Yeh sawal passport services ki knowledge base se bahar hai, is liye main iska jawab nahi de sakta."},
    "ambiguousFee": {
        "en": "Please tell me which service you mean: passport type (MRP or e-Passport), number of pages, validity (5 or 10 years) and service speed (normal, urgent or fast track).",
        "ur": "براہِ کرم واضح کریں کہ آپ کس سروس کے بارے میں پوچھ رہے ہیں: پاسپورٹ کی قسم (MRP یا ای پاسپورٹ)، صفحات کی تعداد، میعاد (5 یا 10 سال) اور سروس کی رفتار (نارمل، ارجنٹ یا فاسٹ ٹریک)۔",
        "roman_ur": "Meherbani karke batayein ke aap kis service ke baare mein pooch rahe hain: passport type (MRP ya e-Passport), pages ki tadaad, validity (5 ya 10 saal) aur service speed (normal, urgent ya fast track)."},
    "vague": {
        "en": "That question is too general. Please add detail, for example documents, renewal, processing time or online application.",
        "ur": "سوال بہت عمومی ہے۔ براہِ کرم مزید تفصیل بتائیں، مثلاً دستاویزات، تجدید، پراسیسنگ کا وقت یا آن لائن درخواست۔",
        "roman_ur": "Sawal bohat aam hai. Meherbani karke tafseel batayein, masalan documents, renewal, processing time ya online application."},
    "personalStatus": {
        "en": "I cannot see individual applications or promise any outcome. Please contact the relevant passport office or the official DGI&P website.",
        "ur": "میں انفرادی درخواستوں کی صورتحال نہیں دیکھ سکتا اور نہ ہی کسی نتیجے کی ضمانت دے سکتا ہوں۔ براہِ کرم متعلقہ پاسپورٹ دفتر یا سرکاری ویب سائٹ سے رجوع کریں۔",
        "roman_ur": "Main individual applications ka status nahi dekh sakta aur na hi kisi nateeje ki zamanat de sakta hoon. Meherbani karke mutaliqa passport office ya official website se rabta karein."},
    "personalTiming": {
        "en": "I cannot give a delivery date for an individual passport. Please confirm with the relevant passport office or the official DGI&P website.",
        "ur": "میں کسی فرد کے پاسپورٹ کی ترسیل کی تاریخ نہیں بتا سکتا۔ براہِ کرم متعلقہ پاسپورٹ دفتر یا سرکاری ویب سائٹ سے تصدیق کریں۔",
        "roman_ur": "Main kisi shakhs ke passport ki delivery ki tareekh nahi bata sakta. Meherbani karke mutaliqa passport office ya official website se tasdeeq karein."},
    "noGuarantee": {
        "en": "The knowledge base does not state any guaranteed fee, time or outcome for an individual applicant, so I cannot promise one.",
        "ur": "علمی ذخیرے میں کسی انفرادی درخواست گزار کے لیے ضمانت شدہ فیس، وقت یا نتیجے کا ذکر نہیں، اس لیے میں ایسا وعدہ نہیں کر سکتا۔",
        "roman_ur": "Knowledge base mein kisi individual applicant ke liye guaranteed fee, waqt ya nateeja darj nahi, is liye main aisa wada nahi kar sakta."},
    "injection": {
        "en": "I answer only from the cited official sources. I will not invent information or drop the citations.",
        "ur": "میں صرف حوالہ دیے گئے سرکاری ذرائع کی بنیاد پر جواب دیتا ہوں؛ نہ معلومات گھڑوں گا اور نہ حوالہ چھوڑوں گا۔",
        "roman_ur": "Main sirf cite kiye gaye official sources ki bunyad par jawab deta hoon; na maloomat ghaDoon ga aur na hawala chhodoon ga."},
    "unsafe": {
        "en": "I cannot help with bypassing official verification. I can explain the documented requirements and process instead.",
        "ur": "میں سرکاری تصدیق کو بائی پاس کرنے میں مدد نہیں کر سکتا۔ البتہ دستاویزی تقاضے اور مراحل بتا سکتا ہوں۔",
        "roman_ur": "Main official verification ko bypass karne mein madad nahi kar sakta. Albatta documents ke taqaze aur marahil bata sakta hoon."},
    "timeSensitive": {
        "en": "The indexed documents are not date-verified for current fees, so I cannot confirm that any figure is still current. Please verify on the official DGI&P website.",
        "ur": "درج شدہ دستاویزات میں فیس کی موجودہ حیثیت کی تاریخ وار تصدیق نہیں، اس لیے میں نہیں کہہ سکتا کہ کوئی رقم اب بھی لاگو ہے۔ براہِ کرم سرکاری ویب سائٹ پر تصدیق کریں۔",
        "roman_ur": "Maujooda documents mein fee ki maujooda surat-e-haal ki tareekh-war tasdeeq nahi, is liye main nahi keh sakta ke koi raqam ab bhi laagu hai. Meherbani karke official website par tasdeeq karein."},
    "conflict": {
        "en": "I can only compare the passages in my knowledge base; I cannot see the other page you mention. Please check the official DGI&P website for the latest version.",
        "ur": "میں صرف اپنے علمی ذخیرے کے حوالوں کا موازنہ کر سکتا ہوں؛ آپ کا ذکر کردہ دوسرا صفحہ میرے پاس نہیں۔ تازہ ترین معلومات کے لیے سرکاری ویب سائٹ دیکھیں۔",
        "roman_ur": "Main sirf apni knowledge base ke hawalon ka muqabla kar sakta hoon; aap ka zikr kiya hua doosra page mere paas nahi. Taza tareen maloomat ke liye official website dekhein."},
    "unsupportedAction": {
        "en": "I cannot book or confirm appointments or submit forms; this prototype only provides information with sources.",
        "ur": "میں اپائنٹمنٹ بک یا تصدیق نہیں کر سکتا اور نہ فارم جمع کرا سکتا ہوں؛ یہ پروٹوٹائپ صرف حوالہ جاتی معلومات فراہم کرتا ہے۔",
        "roman_ur": "Main appointment book ya confirm nahi kar sakta aur na form jama kara sakta hoon; yeh prototype sirf hawale ke saath maloomat deta hai."},
}
answerLeadIn = {
    "en": "According to the official source:",
    "ur": "سرکاری ماخذ کے مطابق:",
    "roman_ur": "Official source ke mutabiq (Roman Urdu tarjuma):",
}


# ------------------------------------------------------------------------------------
# 6. THE ENGINE
# ------------------------------------------------------------------------------------

class EsahulatEngine:
    retrievalMethods = ["keywordBaseline", "keywordNormalized", "semanticRaw", "semanticNormalized", "hybrid"]

    def __init__(self, passages, embedder=None, params=None):
        self.passages = passages
        self.passageIds = [passage["passageId"] for passage in passages]
        self.params = dict(defaultParams)
        if params:
            self.params.update(params)

        passageTexts = [passage["textEn"] + " " + passage["textUr"] for passage in passages]
        self.baselineIndex = BM25Index([rawTokens(text) for text in passageTexts])

        tokenLists = [toSearchTokens(normalizeForSearch(text))[0] for text in passageTexts]
        self.normalizedIndex = BM25Index(tokenLists)
        self.passageTokenSets = [set(tokens) for tokens in tokenLists]

        self.embedder = embedder
        self.passageVectors = None
        if embedder is not None:
            self.passageVectors = embedder.encodePassages([cleanForEmbedding(text) for text in passageTexts])

    # ---------- understanding the question ----------
    def analyseQuery(self, queryText):
        normalizedText = normalizeForSearch(queryText)
        tokens, concepts = toSearchTokens(normalizedText)
        glosses = []
        for conceptId in dict.fromkeys(concepts):           # unique, keep order
            glosses.append(conceptGroups[conceptId][0])
        return {
            "original": queryText,
            "normalizedText": normalizedText,
            "tokens": tokens,
            "concepts": list(dict.fromkeys(concepts)),
            "denseQuery": (normalizedText + " " + " ".join(glosses)).strip(),
        }

    # ---------- scoring ----------
    def scoreAll(self, queryText, analysis=None):
        analysis = analysis or self.analyseQuery(queryText)
        scores = {
            "keywordBaseline": self.baselineIndex.score(rawTokens(queryText)),
            "keywordNormalized": self.normalizedIndex.score(analysis["tokens"]),
        }
        if self.embedder is not None:
            rawVector = self.embedder.encodeQueries([cleanForEmbedding(queryText)])[0]
            normVector = self.embedder.encodeQueries([analysis["denseQuery"]])[0]
            scores["semanticRaw"] = self.passageVectors @ rawVector
            scores["semanticNormalized"] = self.passageVectors @ normVector
        return scores

    def rankingFor(self, method, scores):
        if method == "keywordBaseline":
            return rankByScore(scores["keywordBaseline"], dropZeros=True)
        if method == "keywordNormalized":
            return rankByScore(scores["keywordNormalized"], dropZeros=True)
        if method in ("semanticRaw", "semanticNormalized"):
            return rankByScore(scores[method])
        if method == "hybrid" and "semanticNormalized" not in scores:
            method = "keywordNormalized"                    # no embedder loaded: hybrid degrades to keyword
            return rankByScore(scores["keywordNormalized"], dropZeros=True)
        if method == "hybrid":
            keywordWeight = self.params["keywordWeight"]       # how much we trust keyword vs semantic (tuned on dev)
            keywordScores, semanticScores = scores["keywordNormalized"], scores["semanticNormalized"]
            if self.params.get("fusionMode") == "score":
                # score fusion: squash both score lists to 0..1 and mix them
                mixed = keywordWeight * minMaxScale(keywordScores) + (1 - keywordWeight) * minMaxScale(semanticScores)
                return sorted(range(len(mixed)), key=lambda docIndex: (-mixed[docIndex], -semanticScores[docIndex]))
            # reciprocal rank fusion: a passage ranked high by BOTH searches wins
            fused = defaultdict(float)
            for position, docIndex in enumerate(rankByScore(keywordScores, dropZeros=True)):
                fused[docIndex] += keywordWeight / (rrfConstant + position + 1)
            for position, docIndex in enumerate(rankByScore(semanticScores)):
                fused[docIndex] += (1 - keywordWeight) / (rrfConstant + position + 1)
            return sorted(fused, key=lambda docIndex: (-fused[docIndex], -semanticScores[docIndex]))
        raise ValueError("unknown retrieval method: " + method)

    def search(self, queryText, method="hybrid", topK=5):
        """returns the ids of the best passages for a method (used by the evaluation script)"""
        if method.startswith("semantic") or method == "hybrid":
            if self.embedder is None:
                raise ValueError("this engine was built without an embedder")
        scores = self.scoreAll(queryText)
        order = self.rankingFor(method, scores)[:topK]
        return [self.passageIds[docIndex] for docIndex in order]

    # ---------- confidence features ----------
    def retrievalFeatures(self, queryText, method="hybrid"):
        analysis = self.analyseQuery(queryText)
        scores = self.scoreAll(queryText, analysis)
        order = self.rankingFor(method, scores)
        topIndex = order[0] if order else None
        contentTokens = set(analysis["tokens"])
        coverage, semanticScore = 0.0, None
        if topIndex is not None and contentTokens:
            coverage = len(contentTokens & self.passageTokenSets[topIndex]) / len(contentTokens)
        if topIndex is not None and "semanticNormalized" in scores:
            semanticScore = float(scores["semanticNormalized"][topIndex])
        return {"analysis": analysis, "scores": scores, "order": order, "topIndex": topIndex,
                "coverage": coverage, "semanticScore": semanticScore}

    def passesThresholds(self, features, params=None):
        params = params or self.params
        if features["topIndex"] is None:
            return False
        if features["coverage"] < params["coverageThreshold"]:
            return False
        if features["semanticScore"] is not None and features["semanticScore"] < params["semThreshold"]:
            return False
        return True

    def guardReasonFor(self, features):
        """rules that decide before looking at retrieval scores (returns a reason code or None)"""
        analysis = features["analysis"]
        reason = firstGuardThatFires(analysis["normalizedText"])
        if reason:
            return reason
        conceptSet = set(analysis["concepts"])
        if "fee" in conceptSet and not (conceptSet - {"fee", "passport", "apply"}):
            return "ambiguousFee"                           # "how much does it cost?" -> which service?
        if len(set(analysis["tokens"])) <= 1 and analysis["tokens"]:
            return "vague"
        return None

    # ---------- the full answer ----------
    def answerQuery(self, queryText, responseLanguage="en", method="hybrid", topK=5):
        startTime = time.perf_counter()
        features = self.retrievalFeatures(queryText, method)
        guardReason = self.guardReasonFor(features)
        retrievedIds = [self.passageIds[index] for index in features["order"][:topK]]
        result = {
            "query": queryText, "responseLanguage": responseLanguage, "method": method,
            "decision": None, "reasonCode": None, "message": None, "answerText": None,
            "evidence": [], "retrievedPassageIds": retrievedIds,
            "matchedConcepts": features["analysis"]["concepts"],
            "normalizedQuery": features["analysis"]["normalizedText"],
            "coverage": round(features["coverage"], 3),
            "semanticScore": None if features["semanticScore"] is None else round(features["semanticScore"], 3),
        }
        passes = self.passesThresholds(features)

        if guardReason:
            result["decision"] = "clarify" if guardReason in ("ambiguousFee", "vague") else "abstain"
            result["reasonCode"] = guardReason
            result["message"] = responseMessages[guardReason][responseLanguage]
            if guardReason in guardsThatShowRelatedEvidence and passes:
                result["evidence"] = [self.buildEvidence(features["topIndex"], responseLanguage)]
        elif not passes:
            result["decision"] = "abstain"
            result["reasonCode"] = "outOfDomain" if not features["analysis"]["concepts"] else "noEvidence"
            result["message"] = responseMessages[result["reasonCode"]][responseLanguage]
        else:
            topIndex = features["topIndex"]
            evidence = self.buildEvidence(topIndex, responseLanguage)
            result["decision"] = "answer"
            result["reasonCode"] = "supported"
            result["evidence"] = [evidence]
            result["answerText"] = answerLeadIn[responseLanguage] + " " + self.pickSentences(
                evidence["text"], features["analysis"]["tokens"])
        result["latencyMs"] = round((time.perf_counter() - startTime) * 1000, 2)
        return result

    def buildEvidence(self, passageIndex, responseLanguage):
        passage = self.passages[passageIndex]
        if responseLanguage == "ur":
            shownText = passage["textUr"]
        elif responseLanguage == "roman_ur":
            shownText = passage.get("textRoman", passage["textEn"])   # our own rendering, falls back to English
        else:
            shownText = passage["textEn"]
        return {"passageId": passage["passageId"], "docId": passage["docId"], "sourceUrl": passage["sourceUrl"],
                "topic": passage["topic"], "text": shownText, "textEn": passage["textEn"], "textUr": passage["textUr"],
                "textRoman": passage.get("textRoman", "")}

    def pickSentences(self, text, queryTokens):
        # the answer is a quote from the passage: we keep the sentences that share the most words with the question
        sentences = [part.strip() for part in re.split(r"(?<=[.;؛۔])\s+", text) if part.strip()]
        if len(sentences) <= 1:
            return text
        queryTokenSet = set(queryTokens)
        scored = []
        for position, sentence in enumerate(sentences):
            sentenceTokens = set(toSearchTokens(normalizeForSearch(sentence))[0])
            scored.append((len(sentenceTokens & queryTokenSet), position, sentence))
        best = sorted(scored, key=lambda item: (-item[0], item[1]))[:2]
        if best[0][0] == 0:
            return sentences[0]
        return " ".join(sentence for _, _, sentence in sorted(best, key=lambda item: item[1]))


# ------------------------------------------------------------------------------------
# 6b. QUESTION LANGUAGE DETECTION (only used to pick the response language automatically)
# ------------------------------------------------------------------------------------
romanUrduMarkers = set("""hai hain hy kya kia ka ki ke ko mein se ya aur kon kaun kitna kitni kitne kitnay chahiye chahye
karwana karwanay karna sakta sakti saktay mera meri mujhay liye liay kab kese kaise kesay hota hoti hogi jaye gum bachay
bache zaroori lagtay hon""".split())


def detectQueryLanguage(text):
    if re.search(r"[\u0600-\u06ff]", text):
        return "ur"
    words = basicNormalize(text).split()
    markerCount = sum(word in romanUrduMarkers for word in words)
    return "roman_ur" if words and markerCount >= 1 and markerCount / len(words) >= 0.15 else "en"


# ------------------------------------------------------------------------------------
# 7. LOADING HELPERS
# ------------------------------------------------------------------------------------

def loadJson(path):
    with open(path, encoding="utf-8") as jsonFile:
        return json.load(jsonFile)


def loadTunedParams(path, embedderName):
    try:
        allParams = loadJson(path)
        return allParams.get(embedderName)
    except (OSError, ValueError):
        return None
